#include "flash.h"
#include "main.h"

// Read a half-word (16-bit data) from the specified address
// faddr: read address (this address must be a multiple of 2!!)
// Return value: corresponding data.
u16 STMFLASH_ReadHalfWord(u32 faddr)
{
    return *(vu16*)faddr; 
}
#if STM32_FLASH_WREN   // If writing is enabled
// Write without checking
// WriteAddr: starting address
// pBuffer: data pointer
// NumToWrite: number of half-words (16-bit data)
void STMFLASH_Write_NoCheck(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite)   
{                
    u16 i;
    for(i=0;i<NumToWrite;i++)
    {
        FLASH_ProgramHalfWord(WriteAddr,pBuffer[i]);
        WriteAddr+=2; // address increases by 2.
    }  
} 
// Write the specified length of data starting from the specified address
// WriteAddr: starting address (this address must be a multiple of 2!!)
// pBuffer: data pointer
// NumToWrite: number of half-words (16-bit data) to write.
#if STM32_FLASH_SIZE < 256
#define STM_SECTOR_SIZE 1024 // bytes
#else 
#define STM_SECTOR_SIZE 2048
#endif        
u16 STMFLASH_BUF[STM_SECTOR_SIZE/2]; // Max is 2K bytes
void STMFLASH_Write(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite)    
{
    u32 secpos;    // sector address
    u16 secoff;    // offset address within the sector (calculated in 16-bit words)
    u16 secremain; // remaining address space within the sector (calculated in 16-bit words)
    u16 i;    
    u32 offaddr;   // address after removing 0X08000000
    if(WriteAddr < STM32_FLASH_BASE || (WriteAddr >= (STM32_FLASH_BASE + 1024 * STM32_FLASH_SIZE))) return; // Invalid address
    FLASH_Unlock();                      // Unlock
    offaddr = WriteAddr - STM32_FLASH_BASE;     // Actual offset address.
    secpos = offaddr / STM_SECTOR_SIZE;         // Sector address  0~63 for STM32F103C8T6
    secoff = (offaddr % STM_SECTOR_SIZE) / 2;   // Offset within the sector (2 bytes as the basic unit)
    secremain = STM_SECTOR_SIZE / 2 - secoff;   // Remaining space size in the sector   
    if(NumToWrite <= secremain) secremain = NumToWrite; // No more than the sector range
    while(1) 
    {    
        STMFLASH_Read(secpos * STM_SECTOR_SIZE + STM32_FLASH_BASE, STMFLASH_BUF, STM_SECTOR_SIZE / 2); // Read the entire sector's content
        for(i = 0; i < secremain; i++) // Check data
        {
            if(STMFLASH_BUF[secoff + i] != 0XFFFF) break; // Needs erasing      
        }
        if(i < secremain) // Needs erasing
        {
            FLASH_ErasePage(secpos * STM_SECTOR_SIZE + STM32_FLASH_BASE); // Erase this sector
            for(i = 0; i < secremain; i++) // Copy
            {
                STMFLASH_BUF[i + secoff] = pBuffer[i];      
            }
            STMFLASH_Write_NoCheck(secpos * STM_SECTOR_SIZE + STM32_FLASH_BASE, STMFLASH_BUF, STM_SECTOR_SIZE / 2); // Write the entire sector
        } else STMFLASH_Write_NoCheck(WriteAddr, pBuffer, secremain); // Write already erased, directly into the remaining sector space.                    
        if(NumToWrite == secremain) break; // Writing finished
        else // Writing not finished
        {
            secpos++;                // Sector address increments by 1
            secoff = 0;              // Offset is 0  
            pBuffer += secremain;    // Pointer shifts
            WriteAddr += secremain;  // Write address shifts
            NumToWrite -= secremain; // Half-word count decreases
            if(NumToWrite > (STM_SECTOR_SIZE / 2)) secremain = STM_SECTOR_SIZE / 2; // Can't finish writing in the next sector
            else secremain = NumToWrite; // Can finish writing in the next sector
        }    
    };    
    FLASH_Lock(); // Lock
}
#endif

// Read the specified length of data starting from the specified address
// ReadAddr: starting address
// pBuffer: data pointer
// NumToRead: number of half-words (16-bit data) to read
void STMFLASH_Read(u32 ReadAddr, u16 *pBuffer, u16 NumToRead)     
{
    u16 i;
    for(i = 0; i < NumToRead; i++)
    {
        pBuffer[i] = STMFLASH_ReadHalfWord(ReadAddr); // Read 2 bytes
        ReadAddr += 2; // Offset by 2 bytes    
    }
}

// WriteAddr: starting address
// WriteData: data to write
void Test_Write(u32 WriteAddr, u16 WriteData)     
{
    STMFLASH_Write(WriteAddr, &WriteData, 1); // Write a single word 
}

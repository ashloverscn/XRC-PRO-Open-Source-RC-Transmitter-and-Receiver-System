#include "main.h"
#include "tim.h"

volatile u32 nowTime = 0; // Program running time, in units of 20ms, updated in key.c
volatile u32 clockTime = 0; // Alarm clock set time, in units of 20ms, updated in key.c
extern char timeStr[6]; // Time string
void updateClockTime(void) {
    // Convert nowTime to seconds
    u32 sec = nowTime / 50; // System timing, updated in the TIM3 interrupt service function in key.c
    u16 hour = sec / 3600; // Calculate hours
    u16 min = (sec % 3600) / 60; // Calculate minutes

    // Combine time string without AM/PM
    sprintf((char *)timeStr, "%02d:%02d", hour, min);
}
void drawClockTime(void) {
    static int blink = 0; // Variable to control blink
    static u32 lastBlinkTime = 0; // Time of last blink
    // Update the time string
    updateClockTime();
    // Check if one second has elapsed since the last blink
    if (nowTime - lastBlinkTime >= 50) {
        lastBlinkTime = nowTime; // Update last blink time
        blink = !blink; // Toggle blink state every second
    }
    // Display time string with blinking colon
    if (blink) {
        timeStr[2] = ' '; // Replace ':' with space for blink effect
        OLED_ShowString(70, 18, (u8*)timeStr, 12, 1); // Display hours, minutes, AM/PM
    } else {
        timeStr[2] = ':'; // Restore ':' for non-blinking state
        OLED_ShowString(70, 18, (u8*)timeStr, 12, 1); // Display hours, minutes, AM/PM
    }
}
void initClockDisplay(void) {
    updateClockTime();
    OLED_ShowString(70, 18, (u8*)timeStr, 12, 1); // Display hours, minutes, AM/PM without blinking initially
}



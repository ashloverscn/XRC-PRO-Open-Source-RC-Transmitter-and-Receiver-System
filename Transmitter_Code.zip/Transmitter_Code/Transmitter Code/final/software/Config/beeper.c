#include "beeper.h"

// Buzzer IO initialization
void BEEPER_Init(void)
{
 
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 // Enable clock for GPIOA
	
	// Initialize buzzer pin PA10 as push-pull output
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10;	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 // Push-pull output
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 // IO speed set to 50MHz
	GPIO_Init(GPIOA, &GPIO_InitStructure); // Initialize GPIOA10
	GPIO_ResetBits(GPIOA, GPIO_Pin_10); // Output low
}

void beeperTwiceOnce(u16 nms) {
    Beeper = 1; // Turn on the buzzer
    delay_ms(nms); // Wait for specified time
    Beeper = 0; // Turn off the buzzer
    delay_ms(nms);  // Add a delay between the two beeps
    Beeper = 1; // Turn on the buzzer again
    delay_ms(nms); // Wait for specified time
    Beeper = 0; // Turn off the buzzer
}

// Short beep once
// freq: frequency 1~50000
// void beeperOnce(u16 freq)
// {
//	for (u16 i = 0; i < (u16)freq / 20; i++) {
//		Beeper = 1;
//		delay_us((u16)50000 / freq);
//		Beeper = 0;
//		delay_us((u16)50000 / freq);
//	}
// }
void beeperOnce(u16 nms)
{
	Beeper = 1; // Turn on the buzzer
	delay_ms(nms); // Wait for specified time
	Beeper = 0; // Turn off the buzzer
}

// Sound the buzzer after checking the mode
void keyDownSound(void)
{
	if (setData.keySound == ON) { // Check if key sound is ON
		beeperOnce(6); // Beep for 6 milliseconds
	}
}


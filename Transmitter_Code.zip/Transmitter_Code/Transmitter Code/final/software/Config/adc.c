#include "adc.h"
#include "main.h"

// Define constants
#define ADC1_DR_Address    ((u32)0x4001244C) // ADC1 address
#define sampleNum 20 // Number of samples for median filtering
#define adcNum 9 // Number of ADC channels
#define chNum 8 // Number of channels for PWM

// Function Prototypes
int GetMedianNum(volatile u16 *bArray, int ch);
int GetAverageNum(volatile u16 *bArray, int ch);
u16 Get_Adc(u8 ch);
u16 Get_Adc_Average(u8 ch, u8 times);
float map(float value, float fromLow, float fromHigh, float toLow, float toHigh);
int mapChValue(int val, int lower, int middle, int upper, int reverse);
float EMAFilter(float current_value, float previous_value, float alpha);

// Declare volatile variables
u16 volatile chValue[adcNum * sampleNum]; // ADC sampled values * sampleNum
u16 volatile chResult[chNum]; // Filtered ADC sampled values
u16 volatile PWMvalue[chNum]; // Control PWM duty cycle

float volatile batVolt; // Battery voltage
float minVolt = 3.2; // Minimum voltage of the battery
float maxVolt = 4.2; // Maximum voltage of the battery
float volatile percentage;
u8 volatile batVoltSignal = 0; // Alarm signal: 1 for alarm, 0 for normal

float emaValues[chNum] = {0}; // EMA values for channels

// TIM2 initialization for ADC sampling
void TIM2_Init(u16 arr, u16 psc) {
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); // Enable TIM2 clock

    // Initialize TIM2
    TIM_TimeBaseStructure.TIM_Period = arr; // Set auto-reload value
    TIM_TimeBaseStructure.TIM_Prescaler = psc; // Set prescaler value
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; // Clock division
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; // Up-counting mode
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure); // Initialize TIM2

    // Initialize TIM2 Channel 2 for PWM
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; // PWM mode 1
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; // Enable output
    TIM_OCInitStructure.TIM_Pulse = 9; // Pulse value
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low; // Low polarity
    TIM_OC2Init(TIM2, &TIM_OCInitStructure); // Initialize TIM2 CH2

    TIM_Cmd(TIM2, ENABLE); // Enable TIM2
    TIM_CtrlPWMOutputs(TIM2, ENABLE);
}

// DMA1 initialization for ADC
void DMA1_Init(void) {
    DMA_InitTypeDef DMA_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); // Enable DMA1 clock

    // Initialize DMA1 Channel 1
    DMA_DeInit(DMA1_Channel1);
    DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address; // ADC1 address
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&chValue; // chValue memory address
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC; // Direction: peripheral to memory
    DMA_InitStructure.DMA_BufferSize = adcNum * sampleNum; // DMA buffer size
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; // Peripheral address fixed
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable; // Memory address increment
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord; // 16-bit peripheral data size
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord; // 16-bit memory data size
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular; // Circular mode
    DMA_InitStructure.DMA_Priority = DMA_Priority_High; // High priority
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable; // Disable memory-to-memory
    DMA_Init(DMA1_Channel1, &DMA_InitStructure); // Initialize DMA1

    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE); // Enable transfer complete interrupt

    // Configure NVIC for DMA1 Channel 1
    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    DMA_Cmd(DMA1_Channel1, ENABLE); // Enable DMA1 Channel 1
}

// DMA interrupt handler
void DMA1_Channel1_IRQHandler(void) {
    u16 chIndex;
    u16 PWM_Sum = 0;
    float alpha = 0.1; // Smoothing factor for EMA

    if (DMA_GetITStatus(DMA1_IT_TC1) != RESET) {
        // Channel mapping and filtering
        for (chIndex = 0; chIndex < chNum; chIndex++) {
            float current_value = GetMedianNum(chValue, chIndex);
            emaValues[chIndex] = EMAFilter(current_value, emaValues[chIndex], alpha);
            chResult[chIndex] = (u16)emaValues[chIndex];
        }

        // Value mapping
        for (chIndex = 0; chIndex < chNum; chIndex++) {
            PWMvalue[chIndex] = setData.PWMadjustValue[chIndex] + mapChValue(chResult[chIndex],
                setData.chLower[chIndex], setData.chMiddle[chIndex], setData.chUpper[chIndex], setData.chReverse[chIndex]);
            PPM_Array[chIndex * 2 + 1] = PWMvalue[chIndex] - MS05;
            PWM_Sum += PWMvalue[chIndex];
        }
        PPM_Array[PPM_NUM - 1] = MS20 - PWM_Sum;
        sendDataPacket(); // Send data packet to the receiver

        // Battery voltage calculation and percentage
        float current_bat_value = GetMedianNum(chValue, 8) * 3.3 * 3 * setData.batVoltAdjust / 4095000;
        batVolt = EMAFilter(current_bat_value, batVolt, alpha);
        percentage = ((batVolt - minVolt) / (maxVolt - minVolt)) * 100.0;
        percentage = (percentage < 0.0) ? 0.0 : percentage;
        percentage = (percentage > 99.0) ? 99.0 : percentage;

        // Battery voltage alarm
        batVoltSignal = (batVolt < setData.warnBatVolt) ? 1 : 0;

        DMA_ClearITPendingBit(DMA1_IT_TC1); // Clear interrupt flag
    }
}

// GPIO configuration for analog input (PA0-7, PB0)
void GPIOA_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE); // Enable GPIOA and GPIOB clock

    // Configure PA0-7 and PB0 as analog input
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// ADC initialization
void ADC_Pin_Init(void) {
    GPIOA_Init();
    ADC_InitTypeDef ADC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); // Enable ADC1 clock

    // Initialize ADC1
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent; // Independent mode
    ADC_InitStructure.ADC_ScanConvMode = ENABLE; // Scan mode
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE; // Continuous conversion mode
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_CC2; // External trigger
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right; // Right alignment
    ADC_InitStructure.ADC_NbrOfChannel = adcNum; // Number of channels
    ADC_Init(ADC1, &ADC_InitStructure);

    RCC_ADCCLKConfig(RCC_PCLK2_Div6); // ADC clock configuration (PCLK2 divided by 6, i.e., 12MHz)
    // Configure each ADC channel with a sample time of 239.5 cycles
    for (int i = 0; i < adcNum; i++) {
        ADC_RegularChannelConfig(ADC1, i, i + 1, ADC_SampleTime_239Cycles5);
    }

    ADC_DMACmd(ADC1, ENABLE); // Enable ADC DMA
    ADC_Cmd(ADC1, ENABLE); // Enable ADC1

    ADC_ResetCalibration(ADC1); // Reset calibration
    while (ADC_GetResetCalibrationStatus(ADC1)); // Wait for reset calibration to complete

    ADC_StartCalibration(ADC1); // Start calibration
    while (ADC_GetCalibrationStatus(ADC1)); // Wait for calibration to complete

    ADC_ExternalTrigConvCmd(ADC1, ENABLE); // Enable external trigger
}

// Get ADC value (not used in current implementation)
u16 Get_Adc(u8 ch) {
    ADC_RegularChannelConfig(ADC1, ch, 1, ADC_SampleTime_239Cycles5); // Configure ADC channel
    ADC_SoftwareStartConvCmd(ADC1, ENABLE); // Start ADC conversion
    while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)); // Wait for conversion to complete
    return ADC_GetConversionValue(ADC1); // Return ADC value
}

// Get average ADC value (not used in current implementation)
u16 Get_Adc_Average(u8 ch, u8 times) {
    u32 temp_val = 0;
    for (u8 t = 0; t < times; t++) {
        temp_val += Get_Adc(ch);
        delay_ms(5);
    }
    return temp_val / times;
}

// Map function similar to Arduino's map function
float map(float value, float fromLow, float fromHigh, float toLow, float toHigh) {
    return ((value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow) + toLow);
}
// Convert ADC value to PWM range (1000-2000)
int mapChValue(int val, int lower, int middle, int upper, int reverse) {
    if (val > upper) val = upper;
    if (val < lower) val = lower; // Clamp val to range
    if (val < middle) {
        val = (int)map(val, lower, middle, 1000, 1500);
    } else {
        val = (int)map(val, middle, upper, 1500, 2000);
    }
    return (reverse ? 3000 - val : val);
}

// Median filter to stabilize ADC values
int GetMedianNum(volatile u16 *bArray, int ch) {
    int i, j;
    int bTemp;
    u16 tempArray[sampleNum];

    for (i = 0; i < sampleNum; i++) {
        tempArray[i] = bArray[ch + adcNum * i];
    }

    for (j = 0; j < sampleNum - 1; j++) {
        for (i = 0; i < sampleNum - j - 1; i++) {
            if (tempArray[i] > tempArray[i + 1]) {
                bTemp = tempArray[i];
                tempArray[i] = tempArray[i + 1];
                tempArray[i + 1] = bTemp;
            }
        }
    }

    if (sampleNum & 1) {
        bTemp = tempArray[sampleNum / 2];
    } else {
        bTemp = (tempArray[sampleNum / 2 - 1] + tempArray[sampleNum / 2]) / 2;
    }

    return bTemp;
}

// Average filter to stabilize ADC values
int GetAverageNum(volatile u16 *bArray, int ch) {
    u32 sum = 0;
    for (int i = 0; i < sampleNum; i++) {
        sum += bArray[ch + adcNum * i];
    }
    return sum / sampleNum;
}

// Exponential Moving Average filter
float EMAFilter(float current_value, float previous_value, float alpha) {
    return (alpha * current_value) + ((1 - alpha) * previous_value);
}

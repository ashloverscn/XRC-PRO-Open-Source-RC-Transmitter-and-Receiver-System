#ifndef __ADC_H
#define __ADC_H

#include "stm32f10x.h"
#include "sys.h"

#define adcNum 9        // Number of ADC channels
#define chNum 8         // Number of channels for PWM
#define sampleNum 20   // Number of samples for median filtering

extern volatile u16 chValue[adcNum * sampleNum];  // ADC sampled values * sampleNum
extern volatile u16 chResult[chNum];              // Filtered ADC sampled values
extern volatile u16 PWMvalue[chNum];              // Control PWM duty cycle
extern volatile float batVolt;                    // Battery voltage
extern volatile u8 batVoltSignal;                 // Alarm signal: 1 for alarm, 0 for normal

void TIM2_Init(u16 arr, u16 psc);                 // TIM2 timer initialization
void DMA1_Init(void);                             // DMA initialization
void GPIOA_Init(void);                            // GPIO configuration for analog input
void ADC_Pin_Init(void);                          // ADC initialization
u16 Get_Adc(u8 ch);                               // Get single ADC value (not used in current implementation)
u16 Get_Adc_Average(u8 ch, u8 times);             // Average filtering for ADC sampled values
float map(float value, float fromLow, float fromHigh, float toLow, float toHigh); // Map function
int mapChValue(int val, int lower, int middle, int upper, int reverse); // Channel remapping function
int GetMedianNum(volatile u16 *bArray, int ch);    // Median filtering function

#endif

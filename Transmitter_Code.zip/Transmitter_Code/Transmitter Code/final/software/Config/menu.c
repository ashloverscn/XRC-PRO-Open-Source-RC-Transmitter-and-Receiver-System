#include "menu.h"
#include "main.h"

u16 homeGoIndex = tdwt; // Quick jump menu page for home
u8 volatile nowMenuIndex = 0;
u8 volatile lastMenuIndex = 0;
extern unsigned char logo[];
extern unsigned char logoR[];
extern float percentage;
extern char displayBuffer[16];
char batVoltStr[8];
char percentageStr[5];
char timeStr[9];
u8 iconTop[11] 	= {0X04,0X0C,0X18,0X30,0X60,0XC0,0X60,0X30,0X18,0X0C,0X04};
u8 iconBottom[11]	= {0X80,0XC0,0X60,0X30,0X18,0X0C,0X18,0X30,0X60,0XC0,0X80};
u8 onSign[28] = {0X7F,0XF8,0XFF,0XFC,0XC0,0X0C,0XC2,0X0C,0XC7,0X0C,0XC3,0X8C,0XC1,0XCC,0XC1,0XCC,0XC3,0X8C,0XC7,0X0C,0XCE,0X0C,0X9C,0X0C,0X39,0XFC,0X13,0XF8,};
u8 offSign[28] = {0X7F,0XF8,0XFF,0XFC,0XC0,0X0C,0XC8,0X4C,0XDC,0XEC,0XCF,0XCC,0XC7,0X8C,0XC7,0X8C,0XCF,0XCC,0XDC,0XEC,0XC8,0X4C,0XC0,0X0C,0XFF,0XFC,0X7F,0XF8,};
unsigned char batticon  [] = {
0xFF, 0xFF, 0xFF, 0xFF, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03,
0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03,
0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xC0, 0x03, 0xFF, 0xFF, 0xFF, 0xFF, 0x07, 0xE0
};
unsigned char pcicon [] = {
0xFF, 0xF0, 0xFF, 0xF0, 0xC0, 0x30, 0xC0, 0x30, 0xC0, 0x37, 0xC0, 0x37, 0xC0, 0x3E, 0xC0, 0x3E,
0xC0, 0x3E, 0xC0, 0x3E, 0xC0, 0x37, 0xC0, 0x37, 0xC0, 0x30, 0xC0, 0x30, 0xFF, 0xF0, 0xFF, 0xF0
};
unsigned char iconSignal100[22] = {
	0X00,0X70,0X00,0X70,0X00,0X00,0X03,0XF0,0X03,0XF0,
	0X00,0X00,0X1F,0XF0,0X1F,0XF0,0X00,0X00,0XFF,0XF0,0XFF,0XF0,};
unsigned char iconSignal75[22] = {
0X00,0X70,0X00,0X70,0X00,0X00,0X03,0XF0,0X03,0XF0,0X00,0X00,0X1F,0XF0,0X1F,0XF0,
0X00,0X00,0XAA,0XA0,0X55,0X50,};
unsigned char iconSignal50[22] = {
0X00,0X70,0X00,0X70,0X00,0X00,0X03,0XF0,0X03,0XF0,0X00,0X00,0X0A,0XA0,0X15,0X50,
0X00,0X00,0XAA,0XA0,0X55,0X50,};
unsigned char iconSignal25[22] = {
0X00,0X70,0X00,0X70,0X00,0X00,0X02,0XA0,0X01,0X50,0X00,0X00,0X0A,0XA0,0X15,0X50,
0X00,0X00,0XAA,0XA0,0X55,0X50,};
unsigned char iconSignal0[22] = {
0X00,0X20,0X00,0X50,0X00,0X00,0X02,0XA0,0X01,0X50,0X00,0X00,0X0A,0XA0,0X15,0X50,
0X00,0X00,0XAA,0XA0,0X55,0X50,};
unsigned char iconSignalOff[22] = {
0XFE,0X70,0XBA,0X70,0XD6,0X00,0XEF,0XF0,0XD7,0XF0,0XBA,0X00,0XFF,0XF0,0X1F,0XF0,
0X00,0X00,0XFF,0XF0,0XFF,0XF0,};
unsigned char iconClock[22] = {
	0XEF,0XB0,0XDF,0XF0,0XBD,0XE0,0X7D,0XF0,0X7D,0XF0,
	0X01,0XF0,0X7F,0XF0,0X7F,0XF0,0XBF,0XE0,0XDF,0XF0,0XEF,0XB0,};
unsigned char iconAlarm[24] = {
	0X00,0XC0,0X1F,0XC0,0X3F,0XC0,0X7F,0XC0,0X7F,0XE0,0XFF,0XF0,0XFF,0XF0,0X7F,0XE0,
	0X7F,0XC0,0X3F,0XC0,0X1F,0XC0,0X00,0XC0,};
unsigned char iconAlarmOff[24] = {
	0X00,0XD0,0X1F,0XA0,0X3F,0X40,0X7E,0X80,0X7D,0X60,0XFA,0XF0,0XF5,0XF0,0X6B,0XE0,
	0X57,0XC0,0X2F,0XC0,0X5F,0XC0,0X80,0XC0,};
unsigned char iconSw1000[24] = {
	0X3F,0XFF,0X00,0X7F,0XF9,0X80,0XFF,0XF0,0XC0,0XFF,0XE0,0X40,0XFF,0XE0,0X40,0XFF,
	0XF0,0XC0,0X7F,0XF9,0X80,0X3F,0XFF,0X00,};
unsigned char iconSw1500[24] = {
	0X3F,0XFF,0X00,0X7F,0X3F,0X80,0XFE,0X1F,0XC0,0XFC,0X0F,0XC0,0XFC,0X0F,0XC0,0XFE,
	0X1F,0XC0,0X7F,0X3F,0X80,0X3F,0XFF,0X00,};
unsigned char iconSw2000[24] = {
	0X3F,0XFF,0X00,0X67,0XFF,0X80,0XC3,0XFF,0XC0,0X81,0XFF,0XC0,0X81,0XFF,0XC0,0XC3,
	0XFF,0XC0,0X67,0XFF,0X80,0X3F,0XFF,0X00,};
unsigned char iconPlane[96] = {
	0X00,0X10,0X00,0X30,0X00,0X30,0X00,0X38,0X00,0X78,0X00,0X78,0X00,0X78,0X00,0XFC,
	0X00,0XFF,0X01,0XFC,0X01,0XFC,0X03,0X7C,0X03,0X7C,0X02,0X7C,0X02,0X7C,0X02,0X7C,
	0X02,0XFC,0X02,0XFC,0X02,0XFC,0X03,0XFC,0X03,0XFE,0X03,0XFE,0X01,0XFE,0X01,0XFE,
	0X01,0XFE,0X01,0XFE,0X01,0XFF,0X00,0XFF,0X00,0XFC,0X00,0XFC,0X00,0XFC,0X00,0XF8,
	0X00,0XF8,0X00,0XF8,0X01,0XF8,0X01,0XF8,0X03,0XF8,0X07,0XF0,0X0F,0XF0,0X1F,0XF0,
	0X3F,0XF0,0X7F,0XE0,0XFF,0XE0,0XFE,0XE0,0XFC,0XC0,0XF0,0X00,0XC0,0X00,0X80,0X00,
	};
unsigned char iconCar[96] = {
	0X00,0X00,0X00,0X08,0X00,0XE8,0X01,0XF8,0X01,0XF8,0X03,0XF8,0X03,0X80,0X07,0X38,
	0X06,0X7C,0X0E,0XFE,0X0E,0XFE,0X0E,0XFE,0X0E,0X7C,0X0F,0X38,0X0F,0X80,0X0F,0XF8,
	0X0F,0XF8,0X0F,0XF8,0X1F,0XF8,0X1F,0XF8,0X1F,0XF8,0X17,0XF8,0X37,0XF8,0X27,0XF8,
	0X67,0XF8,0X47,0XF8,0X47,0XF8,0X47,0XF8,0X47,0XF8,0X47,0XF8,0X4F,0XF8,0X4F,0XF8,
	0X4F,0XF8,0X6F,0X80,0X6F,0X38,0X3E,0X7C,0X3E,0XFE,0X3E,0XFE,0X1E,0XFE,0X1E,0X7C,
	0X3F,0X38,0X7F,0X80,0X7F,0XE0,0X6F,0XC0,0X6F,0X80,0X40,0X00,0X40,0X00,0X00,0X00,
	};
unsigned char iconBoat[96] = {
	0X00,0X00,0X01,0X00,0X01,0X80,0X01,0XC0,0X01,0XC0,0X01,0XE0,0X01,0XE0,0X01,0XF0,
	0X01,0XF0,0X01,0XF0,0X01,0XF0,0X01,0XF8,0X01,0XF8,0X01,0XF8,0X01,0XF8,0X01,0XFC,
	0X01,0XFC,0X01,0XFC,0X01,0XFC,0X01,0XFC,0X01,0XFC,0X03,0XFC,0X03,0XFC,0X03,0XFC,
	0X03,0XFC,0X07,0XFC,0X07,0XFC,0X07,0XFC,0X0F,0XFC,0X1F,0XFC,0X01,0XFC,0X01,0XFC,
	0X03,0XFC,0X07,0XFC,0X01,0XFC,0X07,0XFC,0X07,0XFC,0X07,0XFC,0X07,0XFC,0X07,0XF4,
	0X07,0XFE,0X07,0XF4,0X07,0XF0,0X01,0XFE,0X01,0XFE,0X01,0XF0,0X00,0X00,0X00,0X00,
	};

void main2menuList(u8 hz1,u8 hz2,u8 hz3,u8 hz4);
void menuList2tdwt(void);
void menuList2tdzf(void);
void menuList2tdys(void);

Key_index_struct Key_table[MENU_NUM]=
{
	// Current, Down, Up, Confirm, Return, Home
{home, dljs18, dljs18, tdwt, home, home, (*homeWindow)}, // Main page: Home

{tdwt, tdzf, gybj, tdwt1, home, home, (*menu_tdwt)}, // First-level menu: Channel Fine-Tuning
{tdzf, hksz, tdwt, tdzf1, home, home, (*menu_tdzf)}, // First-level menu: Channel Positive and Negative
{hksz, jsgl, tdzf, sjyhk, home, home, (*menu_hksz)}, // First-level menu: Mixed Control Settings
{jsgl, scsz, hksz, xjjs, home, home, (*menu_jsgl)}, // First-level menu: Receiver Management
{scsz, tdys, jsgl, ppmsc, home, home, (*menu_scsz)}, // First-level menu: Output Settings
{tdys, dljs, scsz, tdys1, home, home, (*menu_tdys)}, // First-level menu: Channel Mapping
{dljs, xtsz, tdys, dljs18, home, home, (*menu_dljs)}, // First-level menu: Control Quantity Monitoring
{xtsz, gybj, dljs, cysz, home, home, (*menu_xtsz)}, // First-level menu: System Settings
{gybj, tdwt, xtsz, gybjInf, home, home, (*menu_gybj)}, // First-level menu: About This Machine

{tdwt1, tdwt2, tdwt8, tdwt1, tdwt, home, (*menu_tdwt1)}, // Second-level menu: Channel Fine-Tuning 1
{tdwt2, tdwt3, tdwt1, tdwt2, tdwt, home, (*menu_tdwt2)}, // Second-level menu: Channel Fine-Tuning 2
{tdwt3, tdwt4, tdwt2, tdwt3, tdwt, home, (*menu_tdwt3)}, // Second-level menu: Channel Fine-Tuning 3
{tdwt4, tdwt5, tdwt3, tdwt4, tdwt, home, (*menu_tdwt4)}, // Second-level menu: Channel Fine-Tuning 4
{tdwt5, tdwt6, tdwt4, tdwt5, tdwt, home, (*menu_tdwt5)}, // Second-level menu: Channel Fine-Tuning 5
{tdwt6, tdwt7, tdwt5, tdwt6, tdwt, home, (*menu_tdwt6)}, // Second-level menu: Channel Fine-Tuning 6
{tdwt7, tdwt8, tdwt6, tdwt7, tdwt, home, (*menu_tdwt7)}, // Second-level menu: Channel Fine-Tuning 7
{tdwt8, tdwt1, tdwt7, tdwt8, tdwt, home, (*menu_tdwt8)}, // Second-level menu: Channel Fine-Tuning 8

{tdzf1, tdzf2, tdzf8, tdzf1, tdzf, home, (*menu_tdzf1)}, // Second-level menu: Channel Positive and Negative 1
{tdzf2, tdzf3, tdzf1, tdzf2, tdzf, home, (*menu_tdzf2)}, // Second-level menu: Channel Positive and Negative 2
{tdzf3, tdzf4, tdzf2, tdzf3, tdzf, home, (*menu_tdzf3)}, // Second-level menu: Channel Positive and Negative 3
{tdzf4, tdzf5, tdzf3, tdzf4, tdzf, home, (*menu_tdzf4)}, // Second-level menu: Channel Positive and Negative 4
{tdzf5, tdzf6, tdzf4, tdzf5, tdzf, home, (*menu_tdzf5)}, // Second-level menu: Channel Positive and Negative 5
{tdzf6, tdzf7, tdzf5, tdzf6, tdzf, home, (*menu_tdzf6)}, // Second-level menu: Channel Positive and Negative 6
{tdzf7, tdzf8, tdzf6, tdzf7, tdzf, home, (*menu_tdzf7)}, // Second-level menu: Channel Positive and Negative 7
{tdzf8, tdzf1, tdzf7, tdzf8, tdzf, home, (*menu_tdzf8)}, // Second-level menu: Channel Positive and Negative 8

// Current, Down, Up, Confirm, Return, Home
{sjyhk, vyhk, jfyhk, sjyhk, hksz, home, (*menu_sjyhk)}, // Second-level menu: Triangle Wing Mixed Control
{vyhk, cshk, sjyhk, vyhk, hksz, home, (*menu_vyhk)}, // Second-level menu: V-Wing Mixed Control
{cshk, jfyhk, vyhk, cshk, hksz, home, (*menu_cshk)}, // Second-level menu: Differential Mixed Control
{jfyhk, sjyhk, cshk, jfyhk, hksz, home, (*menu_jfyhk)}, // Second-level menu: Flap Mixed Control

{xjjs, xzmx, txmm, xjjs, jsgl, home, (*menu_xjjs)}, // Second-level menu: New Receiver
{xzmx, bcmx, xjjs, xzmx, jsgl, home, (*menu_xzmx)}, // Second-level menu: Select Model
{bcmx, txmm, xzmx, bcmx, jsgl, home, (*menu_bcmx)}, // Second-level menu: Save Model
{txmm, xjjs, bcmx, txmm, jsgl, home, (*menu_txmm)}, // Second-level menu: Communication Password

{ppmsc, wxfs, fsgl, ppmsc, scsz, home, (*menu_ppmsc)}, // Second-level menu: PPM Output
{wxfs, fsgl, ppmsc, wxfs, scsz, home, (*menu_wxfs)}, // Second-level menu: Wireless Transmission
{fsgl, ppmsc, wxfs, fsgl, scsz, home, (*menu_fsgl)}, // Second-level menu: Transmission Power

{tdys1, tdys2, tdys8, tdys1, tdys, home, (*menu_tdys1)}, // Second-level menu: Channel Mapping 1
{tdys2, tdys3, tdys1, tdys2, tdys, home, (*menu_tdys2)}, // Second-level menu: Channel Mapping 2
{tdys3, tdys4, tdys2, tdys3, tdys, home, (*menu_tdys3)}, // Second-level menu: Channel Mapping 3
{tdys4, tdys5, tdys3, tdys4, tdys, home, (*menu_tdys4)}, // Second-level menu: Channel Mapping 4
{tdys5, tdys6, tdys4, tdys5, tdys, home, (*menu_tdys5)}, // Second-level menu: Channel Mapping 5
{tdys6, tdys7, tdys5, tdys6, tdys, home, (*menu_tdys6)}, // Second-level menu: Channel Mapping 6
{tdys7, tdys8, tdys6, tdys7, tdys, home, (*menu_tdys7)}, // Second-level menu: Channel Mapping 7
{tdys8, tdys1, tdys7, tdys8, tdys, home, (*menu_tdys8)}, // Second-level menu: Channel Mapping 8

{dljs18,home,home,dljs,dljs,home,(*menu_dljs18)}, // Secondary menu: Servo Monitoring 1-8

{cysz,dysz,hfcc,wtdw,xtsz,home,(*menu_cysz)}, // Secondary menu: Common Settings
{dysz,nzsz,cysz,dyjz,xtsz,home,(*menu_dysz)}, // Secondary menu: Voltage Settings
{nzsz,ymsz,dysz,nzbj,xtsz,home,(*menu_nzsz)}, // Secondary menu: Alarm Clock Settings
{ymsz,xcjz,nzsz,ymph,xtsz,home,(*menu_ymsz)}, // Secondary menu: Throttle Settings
{xcjz,hfcc,ymsz,xcjzTip,xtsz,home,(*menu_xcjz)}, // Secondary menu: Travel Calibration
{hfcc,cysz,xcjz,hfccTip,xtsz,home,(*menu_hfcc)}, // Secondary menu: Restore Factory Settings

{wtdw,ajyx,kjhm,wtdw,cysz,home,(*menu_wtdw)}, // Tertiary menu: Fine-Tuning Units
{ajyx,kjhm,wtdw,ajyx,cysz,home,(*menu_ajyx)}, // Tertiary menu: Button Sound Effects
{kjhm,wtdw,ajyx,kjhm,cysz,home,(*menu_kjhm)}, // Tertiary menu: Boot Screen

{dyjz,bjdy,jsbj,dyjz,dysz,home,(*menu_dyjz)}, // Tertiary menu: Voltage Calibration
{bjdy,jsbj,dyjz,bjdy,dysz,home,(*menu_bjdy)}, // Tertiary menu: Alarm Voltage
{jsbj,dyjz,bjdy,jsbj,dysz,home,(*menu_jsbj)}, // Tertiary menu: Receiver Alarm

{nzbj,nzsc,kjzj,nzbj,nzsz,home,(*menu_nzbj)}, // Tertiary menu: Alarm Clock Alarm
{nzsc,kjzj,nzbj,nzsc,nzsz,home,(*menu_nzsc)}, // Tertiary menu: Alarm Clock Duration
{kjzj,nzbj,nzsc,kjzj,nzsz,home,(*menu_kjzj)}, // Tertiary menu: Boot Self-Test

// Current, Down, Up, Confirm, Back, Home
{ymph,ymqx,skbh,ymph,ymsz,home,(*menu_ymph)}, // Tertiary menu: Throttle Preferences
{ymqx,skbh,ymph,ymqx,ymsz,home,(*menu_ymqx)}, // Tertiary menu: Throttle Curve
{skbh,ymph,ymqx,skbh,ymsz,home,(*menu_skbh)}, // Tertiary menu: Fail-Safe Protection

{xcjzTip,xcjzTip,xcjzTip,xcjz14,xcjz,home,(*menu_xcjzTip)}, // Tertiary menu: Travel Calibration Tip
{xcjz14,xcjz14,xcjz14,xcjz,xcjz,home,(*menu_xcjz14)}, // Tertiary menu: Travel Calibration 1-4

{hfccTip,hfccTip,hfccTip,hfcg,hfcc,home,(*menu_hfccTip)}, // Tertiary menu: Restore Factory Settings Tip
{hfcg,hfcg,hfcg,hfcc,hfcc,home,(*menu_hfcg)}, // Tertiary menu: Restore Successful

{gybjInf,gybjInf,gybjInf,gybj,gybj,home,(*menu_gybjInf)}, // Tertiary menu: About This Device Tip

};
// Menu Polling
void OLED_display(void) {
    u16 temp;
    switch(menuEvent[1]) {
        case MENU_down: // Menu Down
            nowMenuIndex = Key_table[nowMenuIndex].down_index; // Move down in the menu
            break;
        case MENU_up: // Menu Up
            nowMenuIndex = Key_table[nowMenuIndex].up_index; // Move up in the menu
            break;
        case MENU_enter: // Confirm
            temp = nowMenuIndex; // Get the previous page
            nowMenuIndex = Key_table[nowMenuIndex].enter_index; // Enter the selected menu
            if(IsInKeyMenu(temp) && IsInKeyMenu(nowMenuIndex)) 
                menuMode = !menuMode; // Short press on the encoder to enter/exit edit mode
            break;
        case MENU_esc: // Return
            nowMenuIndex = Key_table[nowMenuIndex].esc_index; // Return to the previous menu
            menuMode = 0; // Switch to non-editable mode
            break;
        case MENU_home: // Long press to return to the main interface
            nowMenuIndex = Key_table[nowMenuIndex].home_index; // Return to the home menu
            menuMode = 0; // Switch to non-editable mode
            break;
        case NUM_down: // Placeholder for number down
            break;
        case NUM_up: // Placeholder for number up
            break;
    }

if(nowMenuIndex == home && lastMenuIndex != home) 
{
    if(lastMenuIndex != xcjz14 && lastMenuIndex != dljs18) homeGoIndex = lastMenuIndex; // Set homeGoIndex to last menu index
    if(lastMenuIndex == xcjz14) homeGoIndex = xcjz; // Set homeGoIndex to xcjz
    OLED_Clear_GRAM(); // Clear the screen
}
if(nowMenuIndex != home && lastMenuIndex == home && menuEvent[1] == MENU_enter) {nowMenuIndex = homeGoIndex; OLED_Clear_GRAM();} // Clear the screen, achieve quick jump
if(nowMenuIndex >= tdwt && nowMenuIndex <= gybj && (lastMenuIndex < tdwt || lastMenuIndex > gybj)) main2menuList(sheZhi, zhi, cai, dan); // Switch window
if(nowMenuIndex >= tdwt1 && nowMenuIndex <= tdwt8 && (lastMenuIndex < tdwt1 || lastMenuIndex > tdwt8)) menuList2tdwt(); // Switch window
if(nowMenuIndex >= tdzf1 && nowMenuIndex <= tdzf8 && (lastMenuIndex < tdzf1 || lastMenuIndex > tdzf8)) menuList2tdzf(); // Switch window
if(nowMenuIndex >= sjyhk && nowMenuIndex <= jfyhk && (lastMenuIndex < sjyhk || lastMenuIndex > jfyhk)) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex >= xjjs && nowMenuIndex <= txmm && (lastMenuIndex < xjjs || lastMenuIndex > txmm)) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex >= ppmsc && nowMenuIndex <= fsgl && (lastMenuIndex < ppmsc || lastMenuIndex > fsgl)) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex >= tdys1 && nowMenuIndex <= tdys8 && (lastMenuIndex < tdys1 || lastMenuIndex > tdys8)) menuList2tdys(); // Switch window
if(nowMenuIndex == dljs18 && lastMenuIndex != dljs18) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex >= cysz && nowMenuIndex <= hfcc && (lastMenuIndex < cysz || lastMenuIndex > hfcc)) main2menuList(xi, tongYi, sheZhi, zhi); // Switch window
if(nowMenuIndex >= wtdw && nowMenuIndex <= kjhm && (lastMenuIndex < wtdw || lastMenuIndex > kjhm)) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex >= dyjz && nowMenuIndex <= jsbj && (lastMenuIndex < dyjz || lastMenuIndex > jsbj)) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex >= nzbj && nowMenuIndex <= kjzj && (lastMenuIndex < nzbj || lastMenuIndex > kjzj)) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex >= ymph && nowMenuIndex <= skbh && (lastMenuIndex < ymph || lastMenuIndex > skbh)) OLED_Clear_GRAM(); // Clear the screen
if(nowMenuIndex == xcjz14 && lastMenuIndex != xcjz14) OLED_Clear_GRAM(); // Clear the screen
// printf("key:%d, last:%d, now:%d\r\n", menuEvent[1], lastMenuIndex, nowMenuIndex);
if(nowMenuIndex != lastMenuIndex)
{
    Key_table[nowMenuIndex].operate(); // Perform operation for the current menu index
    OLED_Refresh_Gram(); // Refresh display memory
	}
}

void showSwState(void)
{
	u8 i=0;
	for(i=0;i<4;i++)// Display of four auxiliary channels
	{
		if(PWMvalue[4+i]<1250) OLED_DrawPointBMP(14+12*i,18,iconSw1000,11,18,1);
		else if(PWMvalue[4+i]<1750) OLED_DrawPointBMP(14+12*i,18,iconSw1500,11,18,1);
		else OLED_DrawPointBMP(14+12*i,18,iconSw2000,11,18,1);
	}
}

void homeWindow(void)
{
	u16 thrNum;
	int loca;
	
	// Get signal strength
        int strength = getSignalStrength();
	 if (strength == 0) {
        OLED_DrawPointBMP(48, 1, iconSignalOff, 15, 12, 1);
    } else if (strength > 0 && strength <= 25) {
        OLED_DrawPointBMP(48, 1, iconSignal25, 15, 12, 1);
    } else if (strength > 25 && strength <= 50) {
        OLED_DrawPointBMP(48, 1, iconSignal50, 15, 12, 1);
    } else if (strength > 50 && strength <= 75) {
        OLED_DrawPointBMP(48, 1, iconSignal75, 15, 12, 1);
    } else {
        OLED_DrawPointBMP(48, 1, iconSignal100, 15, 12, 1);
    }
	
	// Update alarm icon based on clock mode
    OLED_DrawPointBMP(65, 1, (setData.clockMode == ON) ? iconAlarm : iconAlarmOff, 16, 12, 1);

    // Update PPM output icon and state
    if (setData.PPM_Out == ON) {
        OLED_DrawPointBMP(28, 0, pcicon, 16, 16, 1);
        PPM_ON();
    }

    // Display current time
    drawClockTime();

    // Display switch state
    showSwState();

    // Update model type icon
    switch (setData.modelType) {
        case 0:
            OLED_DrawPointBMP(11, 39, iconPlane, 48, 16, 1);
            break;
        case 1:
            OLED_DrawPointBMP(11, 39, iconCar, 48, 16, 1);
            break;
        default:
            OLED_DrawPointBMP(11, 39, iconBoat, 48, 16, 1);
            break;
    }

// Draw battery icon, "T" label, and battery voltage on OLED display
OLED_DrawPointBMP(103, 0, batticon, 24, 16, 1); // Update x-coordinate to 106
// Check if the percentage is a single-digit number
if (percentage < 10) {
    // Add a leading space for single-digit numbers
    sprintf((char *)percentageStr, " %d%%", (int)percentage);
} else {
    // Format normally for two-digit numbers
    sprintf((char *)percentageStr, "%d%%", (int)percentage);
}

// Display the battery percentage at a fixed x-coordinate
OLED_ShowString(82, 3, (u8 *)percentageStr, 12, 1); 
int fillPixels;
if (batVolt <= 3.2) {
    fillPixels = 0; // Set to minimum if voltage is low.
} else if (batVolt >= 4.2) {
    fillPixels = 16; // Set to maximum if voltage is high.
} else {
    // Linear mapping from voltage range to pixel range.
    fillPixels = (int)((batVolt - 3.2) * (16.0 / 1.0));
}
// Clear the battery fill area before updating it
OLED_Fill(106, 3, 122, 12, 0); // Update x-coordinates to clear from x=109 to x=125 (109+16), height of 12
OLED_Fill(106, 3, (u16)(106 + fillPixels), 12, 1); // Update x-coordinates to fill from x=109 to (109 + fillPixels) with a height of 12.

	OLED_Fill(0,15,4,63,1);// Left frame
OLED_DrawPoint(1,39,0);
OLED_DrawPoint(3,39,0);
OLED_Fill(123,15,127,63,1);// Right frame
OLED_DrawPoint(124,39,0);
OLED_DrawPoint(126,39,0);
OLED_Fill(7,59,62,63,1);// Bottom left frame - 4
OLED_Fill(65,59,120,63,1);// Bottom right frame - 1

if(setData.throttlePreference)// Left-hand throttle
{
    OLED_DrawPoint(35,60,0);// Center marker - 4
    OLED_DrawPoint(35,62,0);// Center marker - 4
    OLED_DrawPoint(93,60,0);// Center marker - 1
    OLED_DrawPoint(93,62,0);// Center marker - 1
    // Channel 1 trim marker - Roll - Right horizontal line
    OLED_Fill(66,61,119,61,1);// Write 1, clear original marker
    loca = (int)93+setData.PWMadjustValue[0]/12.5;
    OLED_Fill(loca-2,61,loca+2,61,0);// Write 0

    // Channel 2 trim marker - Elevator - Right vertical line
    OLED_Fill(125,16,125,62,1);// Write 1
    loca = (int)39-setData.PWMadjustValue[1]/14.29;
    OLED_Fill(125,loca-2,125,loca+2,0);// Write 1

    // Channel 3 throttle travel line - Left vertical line
    thrNum = (int)(PWMvalue[2]-1000)/22;
    OLED_Fill(2,62-thrNum,2,62,0);// Lower part write 1
    OLED_Fill(2,16,2,62-thrNum,1);// Upper part write 0

    // Channel 4 trim marker - Rudder - Left horizontal line
    OLED_Fill(7,61,61,61,1);// Write 1, clear original marker
    loca = (int)35+setData.PWMadjustValue[3]/12.5;
    OLED_Fill(loca-2,61,loca+2,61,0);// Write 0
		OLED_Refresh_Gram(); // Refresh display memory.
	}
	else{// Right-hand throttle
    OLED_DrawPoint(34,60,0);// Center marker - 4
    OLED_DrawPoint(34,62,0);// Center marker - 4
    OLED_DrawPoint(93,60,0);// Center marker - 1
    OLED_DrawPoint(93,62,0);// Center marker - 1
    // Channel 1 trim marker - Roll - Left horizontal line
    OLED_Fill(7,61,61,61,1);// Write 1, clear original marker
    loca = (int)34+setData.PWMadjustValue[0]/12.5;
    OLED_Fill(loca-2,61,loca+2,61,0);// Write 0
    
    // Channel 2 trim marker - Elevator - Left vertical line
    OLED_Fill(2,16,2,62,1);// Write 1
    loca = (int)39-setData.PWMadjustValue[1]/14.29;
    OLED_Fill(2,loca-2,2,loca+2,0);// Write 1
    
    // Channel 3 throttle travel line - Right vertical line
    thrNum = (int)(PWMvalue[2]-1000)/22;
    OLED_Fill(125,62-thrNum,125,62,0);// Lower part write 1
    OLED_Fill(125,16,125,62-thrNum,1);// Upper part write 0
    
    // Channel 4 trim marker - Rudder - Right horizontal line
    OLED_Fill(66,61,119,61,1);// Write 1, clear original marker
    loca = (int)93+setData.PWMadjustValue[3]/12.5;
    OLED_Fill(loca-2,61,loca+2,61,0);// Write 0
	}
	OLED_Refresh_Gram(); // Refresh display memory.
}
// Main window - Level 1 menu switching
void main2menuList(u8 hz1, u8 hz2, u8 hz3, u8 hz4)
{
    OLED_Clear_GRAM();
    OLED_Fill(0, 0, 127, 15, 1); // Top filled
    OLED_Fill(0, 16, 127, 63, 0); // Clear the lower half
    // Top menu bar: Settings menu
    u8 szcdIndex[] = {hz1, hz2, hz3, hz4};
    OLED_ShowChineseWords(32, 0, szcdIndex, 4, 0);
}
/*
listIndex: Sidebar slider positioning, 1~8
mode: Display mode for three lines
str1~3: Strings in the three lines
hzIndex: Index of the twelve Chinese characters in the array for the three lines
*/
void menuListWindow(u8 listIndex, u8 mode[], u8 *str1, u8 *str2, u8 *str3)
{	
    OLED_Clear_GRAM();
    OLED_ShowString(0, 6, str1, 16, mode[0]);
    OLED_ShowString(0, 24, str2, 16, mode[1]);
    OLED_ShowString(0, 42, str3, 16, mode[2]);
}

void showMenu(u8 listIndex, u8 modes[], u8 *str1, u8 *str2, u8 *str3)
{
    menuListWindow(listIndex, modes, str1, str2, str3);
}

void menu_tdwt(void) {
    u8 modes[3] = {0, 1, 1};
    u8 str1[] = "1.CH TUNING   ";
    u8 str2[] = "2.CH INVERT   ";
    u8 str3[] = "3.V-TAIL SETUP";
    showMenu(1, modes, str1, str2, str3);
}

void menu_tdzf(void) {
    u8 modes[3] = {1, 0, 1};
    u8 str1[] = "1.CH TUNING   ";
    u8 str2[] = "2.CH INVERT   ";
    u8 str3[] = "3.V-TAIL SETUP";
    showMenu(2, modes, str1, str2, str3);
}

void menu_hksz(void) {
    u8 modes[3] = {1, 1, 0};
    u8 str1[] = "1.CH TUNING   ";
    u8 str2[] = "2.CH INVERT   ";
    u8 str3[] = "3.V-TAIL SETUP";
    showMenu(3, modes, str1, str2, str3);
}

void menu_jsgl(void) {
    u8 modes[3] = {0, 1, 1};
    u8 str1[] = "4.RX SETTING  ";
    u8 str2[] = "5.OUTPUT SETUP";
    u8 str3[] = "6.YAW SETUP   ";
    showMenu(4, modes, str1, str2, str3);
}

void menu_scsz(void) {
    u8 modes[3] = {1, 0, 1};
    u8 str1[] = "4.RX SETTING  ";
    u8 str2[] = "5.OUTPUT SETUP";
    u8 str3[] = "6.YAW SETUP   ";
    showMenu(5, modes, str1, str2, str3);
}

void menu_tdys(void) {
    u8 modes[3] = {1, 1, 0};
    u8 str1[] = "4.RX SETTING  ";
    u8 str2[] = "5.OUTPUT SETUP";
    u8 str3[] = "6.YAW SETUP   ";
    showMenu(6, modes, str1, str2, str3);
}

void menu_dljs(void) {
    u8 modes[3] = {0, 1, 1};
    u8 str1[] = "7.CH MAPPING  ";
    u8 str2[] = "8.GENERAL SETT";
    u8 str3[] = "9.ABOUT       ";
    showMenu(7, modes, str1, str2, str3);
}

void menu_xtsz(void) {
    u8 modes[3] = {1, 0, 1};
    u8 str1[] = "7.CH MAPPING  ";
    u8 str2[] = "8.GENERAL SETT";
    u8 str3[] = "9.ABOUT       ";
    showMenu(8, modes, str1, str2, str3);
}

void menu_gybj(void) {
    u8 modes[3] = {1, 1, 0};
    u8 str1[] = "7.CH MAPPING  ";
    u8 str2[] = "8.GENERAL SETT";
    u8 str3[] = "9.ABOUT       ";
    showMenu(9, modes, str1, str2, str3);
}

// Level 1 menu - Level 2 menu Channel trim window switching
void menuList2tdwt(void)
{
    OLED_Clear_GRAM(); // Clear the display
    OLED_Fill(63, 0, 64, 63, 1); // Vertical line in the middle
}
/* mode[]: Display mode array for each channel
   lineIndex: Which channel (1-8)
*/
void displayChannel(u8 x, u8 y, u8 channel, u8 mode, s16 value, u8 selected)
{
    OLED_ShowString(x, y, (u8 *)"CH", 16, mode);
    OLED_ShowNum(x + 30, y, abs(value), 3, 16, selected);
    OLED_ShowString(x + 54, y, (u8 *)(value < 0 ? "-" : "+"), 16, 1);
}

void tdwtWindow(u8 mode[], u8 lineIndex)
{
    displayChannel(1, 0, 1, mode[0], setData.PWMadjustValue[0], lineIndex == 1 ? !menuMode : 1);
    displayChannel(1, 16, 2, mode[1], setData.PWMadjustValue[1], lineIndex == 2 ? !menuMode : 1);
    displayChannel(1, 32, 3, mode[2], setData.PWMadjustValue[2], lineIndex == 3 ? !menuMode : 1);
    displayChannel(1, 48, 4, mode[3], setData.PWMadjustValue[3], lineIndex == 4 ? !menuMode : 1);
    displayChannel(66, 0, 5, mode[4], setData.PWMadjustValue[4], lineIndex == 5 ? !menuMode : 1);
    displayChannel(66, 16, 6, mode[5], setData.PWMadjustValue[5], lineIndex == 6 ? !menuMode : 1);
    displayChannel(66, 32, 7, mode[6], setData.PWMadjustValue[6], lineIndex == 7 ? !menuMode : 1);
    displayChannel(66, 48, 8, mode[7], setData.PWMadjustValue[7], lineIndex == 8 ? !menuMode : 1);
}

void menu_tdwt1(void){
    u8 modes[8] = {0, 1, 1, 1, 1, 1, 1, 1}; // Level 2 menu: Channel 1
    tdwtWindow(modes, 1);
}
void menu_tdwt2(void){
    u8 modes[8] = {1, 0, 1, 1, 1, 1, 1, 1}; // Level 2 menu: Channel 2
    tdwtWindow(modes, 2);
}
void menu_tdwt3(void){
    u8 modes[8] = {1, 1, 0, 1, 1, 1, 1, 1}; // Level 2 menu: Channel 3
    tdwtWindow(modes, 3);
}
void menu_tdwt4(void){
    u8 modes[8] = {1, 1, 1, 0, 1, 1, 1, 1}; // Level 2 menu: Channel 4
    tdwtWindow(modes, 4);
}
void menu_tdwt5(void){
    u8 modes[8] = {1, 1, 1, 1, 0, 1, 1, 1}; // Level 2 menu: Channel 5
    tdwtWindow(modes, 5);
}
void menu_tdwt6(void){
    u8 modes[8] = {1, 1, 1, 1, 1, 0, 1, 1}; // Level 2 menu: Channel 6
    tdwtWindow(modes, 6);
}
void menu_tdwt7(void){
    u8 modes[8] = {1, 1, 1, 1, 1, 1, 0, 1}; // Level 2 menu: Channel 7
    tdwtWindow(modes, 7);
}
void menu_tdwt8(void){
    u8 modes[8] = {1, 1, 1, 1, 1, 1, 1, 0}; // Level 2 menu: Channel 8
    tdwtWindow(modes, 8);
}

// Level 1 menu - Level 2 menu Channel trim window switching
void menuList2tdzf(void)
{
    OLED_Clear_GRAM(); // Clear the display
    OLED_Fill(63, 0, 64, 63, 1); // Vertical line in the middle
}
/* mode[]: Display mode array for each channel
   listIndex: Which channel (1-8)
*/
void displayChannelReverse(u8 x, u8 y, u8 channel, u8 mode, u8 reverse, u8 selected) {
    char chStr[4];
    snprintf(chStr, sizeof(chStr), "CH%d", channel);

    OLED_ShowString(x, y, (u8 *)chStr, 16, mode);

    if (reverse == ON) {
        OLED_DrawPointBMP(x + 30, y + 1, onSign, 16, 14, selected);
    } else {
        OLED_DrawPointBMP(x + 30, y + 1, offSign, 16, 14, selected);
    }
}

void tdzfWindow(u8 mode[], u8 listIndex) {
    displayChannelReverse(1, 0, 1, mode[0], setData.chReverse[0], listIndex == 1 ? !menuMode : 1);
    displayChannelReverse(1, 16, 2, mode[1], setData.chReverse[1], listIndex == 2 ? !menuMode : 1);
    displayChannelReverse(1, 32, 3, mode[2], setData.chReverse[2], listIndex == 3 ? !menuMode : 1);
    displayChannelReverse(1, 48, 4, mode[3], setData.chReverse[3], listIndex == 4 ? !menuMode : 1);
    displayChannelReverse(66, 0, 5, mode[4], setData.chReverse[4], listIndex == 5 ? !menuMode : 1);
    displayChannelReverse(66, 16, 6, mode[5], setData.chReverse[5], listIndex == 6 ? !menuMode : 1);
    displayChannelReverse(66, 32, 7, mode[6], setData.chReverse[6], listIndex == 7 ? !menuMode : 1);
    displayChannelReverse(66, 48, 8, mode[7], setData.chReverse[7], listIndex == 8 ? !menuMode : 1);
}

void menu_tdzf1(void){
    u8 modes[8] = {0, 1, 1, 1, 1, 1, 1, 1}; // Level 2 menu: Channel 1
    tdzfWindow(modes, 1);
}
void menu_tdzf2(void){
    u8 modes[8] = {1, 0, 1, 1, 1, 1, 1, 1}; // Level 2 menu: Channel 2
    tdzfWindow(modes, 2);
}
void menu_tdzf3(void){
    u8 modes[8] = {1, 1, 0, 1, 1, 1, 1, 1}; // Level 2 menu: Channel 3
    tdzfWindow(modes, 3);
}
void menu_tdzf4(void){
    u8 modes[8] = {1, 1, 1, 0, 1, 1, 1, 1}; // Level 2 menu: Channel 4
    tdzfWindow(modes, 4);
}
void menu_tdzf5(void){
    u8 modes[8] = {1, 1, 1, 1, 0, 1, 1, 1}; // Level 2 menu: Channel 5
    tdzfWindow(modes, 5);
}
void menu_tdzf6(void){
    u8 modes[8] = {1, 1, 1, 1, 1, 0, 1, 1}; // Level 2 menu: Channel 6
    tdzfWindow(modes, 6);
}
void menu_tdzf7(void){
    u8 modes[8] = {1, 1, 1, 1, 1, 1, 0, 1}; // Level 2 menu: Channel 7
    tdzfWindow(modes, 7);
}
void menu_tdzf8(void){
    u8 modes[8] = {1, 1, 1, 1, 1, 1, 1, 0}; // Level 2 menu: Channel 8
	tdzfWindow(modes, 8);
}
/* 
listIndex: 0-3 
mode: Display mode for four lines 
*/
void hkszWindow(u8 listIndex, u8 mode[]) {
    OLED_Clear_GRAM();
    OLED_ShowString(0, 0, (u8 *)"1.", 16, mode[0]);
    OLED_ShowString(0, 16, (u8 *)"2.", 16, mode[1]);
    OLED_ShowString(0, 32, (u8 *)"3.", 16, mode[2]);
    OLED_ShowString(0, 48, (u8 *)"4.", 16, mode[3]);
}

void setupHkszWindow(u8 listIndex) {
    u8 modes[4] = {1, 1, 1, 1};
    modes[listIndex] = 0;  // Set the selected index to 0 (active)
    hkszWindow(listIndex, modes);
}

void menu_sjyhk(void) {
    setupHkszWindow(0);
} // Level 2 menu: Delta Wing Mixed Control

void menu_vyhk(void) {
    setupHkszWindow(1);
} // Level 2 menu: V Wing Mixed Control

void menu_cshk(void) {
    setupHkszWindow(2);
} // Level 2 menu: Differential Control

void menu_jfyhk(void) {
    setupHkszWindow(3);
} // Level 2 menu: Flap Aileron Mixed Control

/*
listIndex: 0-3
mode: Display mode for four lines
*/
void jsglWindow(u8 listIndex, u8 mode[]) {
	OLED_Clear_GRAM();
    // First line
    OLED_ShowString(0, 0, (u8 *)"1.", 16, mode[0]);

    // Second line
    OLED_ShowString(0, 16, (u8 *)"2.RX TYPE", 16, mode[1]);
    if (setData.modelType == 0) OLED_ShowString(95, 16,(u8 *) "JET ", 16, listIndex == 1 ? !menuMode : 1);
    else if (setData.modelType == 1) OLED_ShowString(95, 16,(u8 *) "CAR ", 16, listIndex == 1 ? !menuMode : 1);
    else OLED_ShowString(95, 16,(u8 *) "BOAT", 16, listIndex == 1 ? !menuMode : 1);

    // Third line
    OLED_ShowString(0, 32, (u8 *)"3.", 16, mode[2]);

    // Fourth line
    OLED_ShowString(0, 48, (u8 *)"4.", 16, mode[3]);
}

void menu_xjjs(void){
	u8 modes[4]={0,1,1,1};
	jsglWindow(0,modes);
} // Level 2 menu: New Receiver

void menu_xzmx(void){
	u8 modes[4]={1,0,1,1};
	jsglWindow(1,modes);
} // Level 2 menu: Select Model

void menu_bcmx(void){
	u8 modes[4]={1,1,0,1};
	jsglWindow(2,modes);
} // Level 2 menu: Save Model

void menu_txmm(void){
	u8 modes[4]={1,1,1,0};
	jsglWindow(3,modes);
} // Level 2 menu: Communication Password

/*
Output Settings
listIndex: 0-3
mode: Display mode for four lines
*/
void scszWindow(u8 listIndex,u8 mode[])
{
	OLED_Clear_GRAM();
OLED_ShowString(0,6,(u8 *)"1.PPM PC",16,mode[0]);
if(setData.PPM_Out == ON) 
{
    OLED_DrawPointBMP(96,7,onSign,16,14,listIndex==0?!menuMode:1);// Open indicator
    PPM_ON();// Enable PPM output
}
else 
{
    OLED_DrawPointBMP(96,7,offSign,16,14,listIndex==0?!menuMode:1);// Close indicator
    PPM_OFF();// Disable PPM output
}
// Third line
OLED_ShowString(0,24,(u8 *)"2.WIRELESS",16,mode[1]);

if(setData.NRF_Mode == ON) 
{
    OLED_DrawPointBMP(96,25,onSign,16,14,listIndex==1?!menuMode:1);// Open indicator
    NRF24L01_TX_Mode(setData.NRF_Power);// Transmit mode
}
else 
{
    OLED_DrawPointBMP(96,25,offSign,16,14,listIndex==1?!menuMode:1);// Close indicator
    NRF24L01_LowPower_Mode();// Low power mode
}
// Fourth line
OLED_ShowString(0, 42, (u8 *)"3.TX POWER", 16, mode[2]);

switch (setData.NRF_Power) {
    case 0x0f:
        OLED_ShowString(96, 42, (u8 *)"99%", 16, listIndex == 2 ? !menuMode : 1);
        if (setData.NRF_Mode == ON) {
            NRF24L01_TX_Mode(setData.NRF_Power); // Set transmission power to high
        }
        break;

    case 0x0d:
        OLED_ShowString(96, 42, (u8 *)"75%", 16, listIndex == 2 ? !menuMode : 1);
        if (setData.NRF_Mode == ON) {
            NRF24L01_TX_Mode(setData.NRF_Power); // Set transmission power to medium
        }
        break;

    case 0x0b:
        OLED_ShowString(96, 42, (u8 *)"50%", 16, listIndex == 2 ? !menuMode : 1);
        if (setData.NRF_Mode == ON) {
            NRF24L01_TX_Mode(setData.NRF_Power); // Set transmission power to low
        }
        break;

    default:
        break;
}

}
void menu_ppmsc(void){
	u8 modes[3]={0,1,1};
	scszWindow(0,modes);
}// Second-level menu: PPM output
void menu_wxfs(void){
	u8 modes[3]={1,0,1};
	scszWindow(1,modes);
}// Second-level menu: Wireless transmission
void menu_fsgl(void){
	u8 modes[3]={1,1,0};
	scszWindow(2,modes);
}// Second-level menu: Transmission power

// First-level menu - Second-level menu channel mapping window switch
void menuList2tdys(void)
{
	OLED_Clear_GRAM();// Clear
	OLED_Fill(63,0,64,63,1);// Middle vertical line
}

/*mode[]: Display mode array for each CH
listIndex: 1-8
*/ 
void tdysWindow(u8 mode[], u8 listIndex)
{
	OLED_ShowString(1,0, (u8 *)"CH1",12,mode[0]);
	OLED_ShowString(40,0, (u8 *)"Y1",12,listIndex==1?!menuMode:1);// This section should read setData and use if statements to display.
	
	OLED_ShowString(1,16, (u8 *)"CH2",12,mode[1]);
	OLED_ShowString(40,16, (u8 *)"Y2",12,listIndex==2?!menuMode:1);
	
	OLED_ShowString(1,32, (u8 *)"CH3",12,mode[2]);
	OLED_ShowString(40,32, (u8 *)"Y3",12,listIndex==3?!menuMode:1);
	
	OLED_ShowString(1,48, (u8 *)"CH4",12,mode[3]);
	OLED_ShowString(40,48, (u8 *)"Y4",12,listIndex==4?!menuMode:1);
	
	OLED_ShowString(66,0, (u8 *)"CH5",12,mode[4]);
	OLED_ShowString(105,0, (u8 *)"K1",12,listIndex==5?!menuMode:1);
	
	OLED_ShowString(66,16, (u8 *)"CH6",12,mode[5]);
	OLED_ShowString(105,16, (u8 *)"K2",12,listIndex==6?!menuMode:1);
	
	OLED_ShowString(66,32, (u8 *)"CH7",12,mode[6]);
	OLED_ShowString(105,32, (u8 *)"K3",12,listIndex==7?!menuMode:1);
	
	OLED_ShowString(66,48, (u8 *)"CH8",12,mode[7]);
	OLED_ShowString(105,48, (u8 *)"K4",12,listIndex==8?!menuMode:1);
}
void menu_tdys1(void){
	u8 modes[8]={0,1,1,1,1,1,1,1};
	tdysWindow(modes, 1);
}// Secondary menu: Channel 1

void menu_tdys2(void){
	u8 modes[8]={1,0,1,1,1,1,1,1};
	tdysWindow(modes, 2);
}// Secondary menu: Channel 2

void menu_tdys3(void){
	u8 modes[8]={1,1,0,1,1,1,1,1};
	tdysWindow(modes, 3);
}// Secondary menu: Channel 3

void menu_tdys4(void){
	u8 modes[8]={1,1,1,0,1,1,1,1};
	tdysWindow(modes, 4);
}// Secondary menu: Channel 4

void menu_tdys5(void){
	u8 modes[8]={1,1,1,1,0,1,1,1};
	tdysWindow(modes, 5);
}// Secondary menu: Channel 5

void menu_tdys6(void){
	u8 modes[8]={1,1,1,1,1,0,1,1};
	tdysWindow(modes, 6);
}// Secondary menu: Channel 6

void menu_tdys7(void){
	u8 modes[8]={1,1,1,1,1,1,0,1};
	tdysWindow(modes, 7);
}// Secondary menu: Channel 7

void menu_tdys8(void){
	u8 modes[8]={1,1,1,1,1,1,1,0};
	tdysWindow(modes, 8);
}// Secondary menu: Channel 8

u8 chLineLen[8];
void menu_dljs18(void){
	u8 num,temp;
	for(num=0;num<8;num++)
	{
		temp = map(PWMvalue[num],1000+setData.PWMadjustValue[num],2000+setData.PWMadjustValue[num],0,63);
		if(nowMenuIndex!=lastMenuIndex|chLineLen[num]!=temp){
			OLED_Fill(16*num+4,63-temp,16*num+12,63,1);// Write 1 to the lower part
			OLED_Fill(16*num+4,0,16*num+12,63-temp,0);// Write 0 to the upper part
			chLineLen[num]=temp;
		}
	}
}// Secondary menu: Channel 1-8 Control Surface Monitoring

void menu_cysz(void){
	u8 modes[3]={0,1,1};
	u8 str1[]="1.TUNE SETTING";
	u8 str2[]="2.VOLT SETTING";
	u8 str3[]="3.CLOCK SETUP ";
	menuListWindow(1,modes,str1,str2,str3);
}// Secondary menu: Common Settings
void menu_dysz(void){
	u8 modes[3]={1,0,1};
	u8 str1[]="1.TUNE SETTING";
	u8 str2[]="2.VOLT SETTING";
	u8 str3[]="3.CLOCK SETUP ";
	menuListWindow(2,modes,str1,str2,str3);
}// Secondary menu: Voltage Settings
void menu_nzsz(void){
	u8 modes[3]={1,1,0};
	u8 str1[]="1.TUNE SETTING";
	u8 str2[]="2.VOLT SETTING";
	u8 str3[]="3.CLOCK SETUP ";
	menuListWindow(3,modes,str1,str2,str3);
}// Secondary menu: Clock Settings
void menu_ymsz(void){
	u8 modes[3]={0,1,1};
	u8 str1[]="4.THRTLE SETUP";
	u8 str2[]="5.STICK ADJUST";
	u8 str3[]="6.RESTORE     ";
	menuListWindow(4,modes,str1,str2,str3);
}// Secondary menu: Throttle Settings
void menu_xcjz(void){
	u8 modes[3]={1,0,1};
	u8 str1[]="4.THRTLE SETUP";
	u8 str2[]="5.STICK ADJUST";
	u8 str3[]="6.RESTORE     ";
	menuListWindow(5,modes,str1,str2,str3);
}// Secondary menu: Travel Calibration
void menu_hfcc(void){
	u8 modes[3]={1,1,0};
	u8 str1[]="4.THRTLE SETUP";
	u8 str2[]="5.STICK ADJUST";
	u8 str3[]="6.RESTORE     ";
	menuListWindow(6,modes,str1,str2,str3);
}// Secondary menu: Restore Factory Settings
/*
hzIndex: Index of 16 Chinese characters in the array
mode: Display mode for three lines
*/
void line3Window(u8 listIndex,u8 mode[],u8 *str1,u8 *str2,u8 *str3)
{	
	OLED_Clear_GRAM();
	OLED_ShowString(0,8,str1,12,mode[0]);
	OLED_ShowString(0,26,str2,12,mode[1]);
	OLED_ShowString(0,42,str3,12,mode[2]);	
}

void menu_wtdw(void){
	u8 modes[3] = {0,1,1};
	u8 str1[]="1.ADJUST UNIT";
	u8 str2[]="2.BUZZER MODE";
	u8 str3[]="3.LOGO MODE  ";
	line3Window(1,modes,str1,str2,str3);
	OLED_ShowNum(95,8,setData.PWMadjustUnit,1,12,!menuMode);
	if(setData.keySound == ON) 
	{
		OLED_DrawPointBMP(95,26,onSign,16,14,1);// Open flag
	}                                                        
	else 
	{
		OLED_DrawPointBMP(95,26,offSign,16,14,1);// Close flag
	}
	OLED_ShowNum(95,42,setData.onImage,1,12,1);
}// Tertiary menu: Trim Unit
void menu_ajyx(void){
	u8 modes[3] = {1,0,1};
	u8 str1[]="1.ADJUST UNIT";
	u8 str2[]="2.BUZZER MODE";
	u8 str3[]="3.LOGO MODE  ";
	line3Window(2,modes,str1,str2,str3);
	OLED_ShowNum(95,8,setData.PWMadjustUnit,1,12,!menuMode);
	if(setData.keySound == ON) 
	{
		OLED_DrawPointBMP(95,26,onSign,16,14,1);// Open flag
	}                                                        
	else 
	{
		OLED_DrawPointBMP(95,26,offSign,16,14,1);// Close flag
	}
	OLED_ShowNum(95,42,setData.onImage,1,12,1);
}// Tertiary menu: Trim Unit
void menu_kjhm(void){
	u8 modes[3] = {1,1,0};
	u8 str1[]="1.ADJUST UNIT";
	u8 str2[]="2.BUZZER MODE";
	u8 str3[]="3.LOGO MODE  ";
	line3Window(3,modes,str1,str2,str3);
	OLED_ShowNum(95,8,setData.PWMadjustUnit,1,12,!menuMode);
	if(setData.keySound == ON) 
	{
		OLED_DrawPointBMP(95,26,onSign,16,14,1);// Open flag
	}                                                        
	else 
	{
		OLED_DrawPointBMP(95,26,offSign,16,14,1);// Close flag
	}
	OLED_ShowNum(95,42,setData.onImage,1,12,1);
}// Tertiary menu: Trim Unit

void menu_dyjz(void){
	u8 modes[3] = {0,1,1};
	u8 str1[]="1.TX VOLT    ";
	u8 str2[]="2.WARN VOLT  ";
	u8 str3[]="3.RX VOLT    ";
	line3Window(1,modes,str1,str2,str3);
	sprintf((char *)batVoltStr,"%1.2fV",batVolt);
	OLED_ShowString(88,8, (u8 *)batVoltStr,12,!menuMode);
	sprintf((char *)batVoltStr,"%1.2fV",setData.warnBatVolt);
	OLED_ShowString(88,26, (u8 *)batVoltStr,12,1);
	sprintf((char *)batVoltStr,"%2.1fV",setData.RecWarnBatVolt);// Aircraft Battery Alarm
	OLED_ShowString(88,42, (u8 *)batVoltStr,12,1);
}// Tertiary Menu: Voltage Calibration
void menu_bjdy(void){
	u8 modes[3] = {1,0,1};
	u8 str1[]="1.TX VOLT    ";
	u8 str2[]="2.WARN VOLT  ";
	u8 str3[]="3.RX VOLT    ";
	line3Window(2,modes,str1,str2,str3);
	sprintf((char *)batVoltStr,"%1.2fV",batVolt);
	OLED_ShowString(88,8, (u8 *)batVoltStr,12,1);
	sprintf((char *)batVoltStr,"%1.2fV",setData.warnBatVolt);
	OLED_ShowString(88,26, (u8 *)batVoltStr,12,!menuMode);
	sprintf((char *)batVoltStr,"%2.1fV",setData.RecWarnBatVolt);// Aircraft Battery Alarm
	OLED_ShowString(88,42, (u8 *)batVoltStr,12,1);
}// Tertiary Menu: Alarm Voltage
void menu_jsbj(void){
	u8 modes[3] = {1,1,0};
	u8 str1[]="1.TX VOLT    ";
	u8 str2[]="2.WARN VOLT  ";
	u8 str3[]="3.RX VOLT    ";
	line3Window(3,modes,str1,str2,str3);
	sprintf((char *)batVoltStr,"%1.2fV",batVolt);
	OLED_ShowString(88,8, (u8 *)batVoltStr,12,1);
	sprintf((char *)batVoltStr,"%1.2fV",setData.warnBatVolt);
	OLED_ShowString(88,26, (u8 *)batVoltStr,12,1);
	sprintf((char *)batVoltStr,"%2.1fV",setData.RecWarnBatVolt);// Aircraft Battery Alarm
	OLED_ShowString(88,42, (u8 *)batVoltStr,12,!menuMode);
}// Tertiary Menu: Alarm Voltage
	
void menu_nzbj(void){
    u8 modes[3] = {0,1,1};
    u8 str1[]="1.CLOCK MODE ";
    u8 str2[]="2.ALARM TIME ";
    u8 str3[]="3.PROTECTION ";
    line3Window(1,modes,str1,str2,str3);
    if(setData.clockMode == ON) 
    {
        OLED_DrawPointBMP(94,8,onSign,16,14,!menuMode);// Open sign
    }
    else 
    {
        OLED_DrawPointBMP(94,8,offSign,16,14,!menuMode);// Close sign
    }
    sprintf((char *)timeStr,"%02dmin",setData.clockTime);
    OLED_ShowString(88,26, (u8 *)timeStr,12,1);// Alarm timer duration in minutes
    if(setData.clockCheck == ON) 
    {
        OLED_DrawPointBMP(94,42,onSign,16,14,1);// Open sign
    }
    else 
    {
        OLED_DrawPointBMP(94,42,offSign,16,14,1);// Close sign
    }
}// Tertiary menu: Alarm Alert
void menu_nzsc(void){
	u8 modes[3] = {1,0,1};
	u8 str1[]="1.CLOCK MODE ";
	u8 str2[]="2.ALARM TIME ";
	u8 str3[]="3.PROTECTION ";
	line3Window(2,modes,str1,str2,str3);
	if(setData.clockMode == ON) 
	{
		OLED_DrawPointBMP(94,8,onSign,16,14,!menuMode);// Open sign
	}
	else 
	{
		OLED_DrawPointBMP(94,8,offSign,16,14,!menuMode);// Close sign
	}
	sprintf((char *)timeStr,"%02dmin",setData.clockTime);
	OLED_ShowString(88,26, (u8 *)timeStr,12,1);// Alarm timer duration in minutes
	if(setData.clockCheck == ON) 
	{
		OLED_DrawPointBMP(94,42,onSign,16,14,1);// Open sign
	}
	else 
	{
		OLED_DrawPointBMP(94,42,offSign,16,14,1);// Close sign
	}
}// Tertiary menu: Alarm Alert
void menu_kjzj(void){
	u8 modes[3] = {1,1,0};
	u8 str1[]="1.CLOCK MODE ";
	u8 str2[]="2.ALARM TIME ";
	u8 str3[]="3.PROTECTION ";
	line3Window(3,modes,str1,str2,str3);
	if(setData.clockMode == ON) 
	{
		OLED_DrawPointBMP(94,8,onSign,16,14,!menuMode);//�򿪱�־
	}
	else 
	{
		OLED_DrawPointBMP(94,8,offSign,16,14,!menuMode);// Close sign
	}
	sprintf((char *)timeStr,"%02dmin",setData.clockTime);
	OLED_ShowString(88,26, (u8 *)timeStr,12,1);// Alarm timer duration in minutes
	if(setData.clockCheck == ON) 
	{
		OLED_DrawPointBMP(94,42,onSign,16,14,1);// Open sign
	}
	else 
	{
		OLED_DrawPointBMP(94,42,offSign,16,14,1);// Close sign
	}
}// Tertiary menu: Alarm Alert
	
void menu_ymph(void){
    u8 modes[3] = {0,1,1};
    u8 str1[]="1.THRTLE HAND";
    u8 str2[]="2.CURVE MODE ";
    u8 str3[]="3.PROTECTION ";
    line3Window(1,modes,str1,str2,str3);
    if(setData.throttlePreference)OLED_ShowString(92,10, (u8 *)"LEFT ",12,1);    
    else OLED_ShowString(92,10, (u8 *)"RIGHT",12,1);    
    sprintf((char *)timeStr,"%03d%%",setData.throttleProtect);
    OLED_ShowString(88,42, (u8 *)timeStr,12,1);// Throttle protection value 0%
}// Tertiary menu: Throttle Preference
void menu_ymqx(void){
	u8 modes[3] = {1,0,1};
	u8 str1[]="1.THRTLE HAND";
	u8 str2[]="2.CURVE MODE ";
	u8 str3[]="3.PROTECTION ";
	line3Window(2,modes,str1,str2,str3);
	if(setData.throttlePreference)OLED_ShowString(92,10, (u8 *)"LEFT ",12,1);	
	else OLED_ShowString(92,10, (u8 *)"RIGHT",12,1);	
	sprintf((char *)timeStr,"%03d%%",setData.throttleProtect);
	OLED_ShowString(88,42, (u8 *)timeStr,12,1);// Throttle protection value 0%
}// Tertiary menu: Throttle Preference
void menu_skbh(void){
	u8 modes[3] = {1,1,0};
	u8 str1[]="1.THRTLE HAND";
	u8 str2[]="2.CURVE MODE ";
	u8 str3[]="3.PROTECTION ";
	line3Window(3,modes,str1,str2,str3);
	if(setData.throttlePreference)OLED_ShowString(92,10, (u8 *)"LEFT ",12,1);	
	else OLED_ShowString(92,10, (u8 *)"RIGHT",12,1);	
	sprintf((char *)timeStr,"%03d%%",setData.throttleProtect);
	OLED_ShowString(88,42, (u8 *)timeStr,12,!menuMode);// Throttle protection value 0%
}// Tertiary menu: Throttle Preference

void menu_xcjzTip(void){
	OLED_Clear_GRAM();//OLED CLEAR GRAM
	OLED_ShowString(4,8, (u8 *)"1.Centre the Sticks.",12,1);	
	OLED_ShowString(4,20, (u8 *)"2.PRESS ENTER.",12,1);
	OLED_ShowString(4,32, (u8 *)"3.Move the Sticks",12,1);
	OLED_ShowString(14,44, (u8 *)"in all direction.",12,1);	
}// Tertiary menu: Please center the joystick
void menu_xcjz14(void){
	OLED_ShowString(2,0, (u8 *)"A:",16,1);
	OLED_ShowNum(18,0,setData.chLower[0],4,16,1);
	OLED_ShowNum(56,0,setData.chMiddle[0],4,16,1);
	OLED_ShowNum(95,0,setData.chUpper[0],4,16,1);
	
	OLED_ShowString(2,16, (u8 *)"E:",16,1);
	OLED_ShowNum(18,16,setData.chLower[1],4,16,1);
	OLED_ShowNum(56,16,setData.chMiddle[1],4,16,1);
	OLED_ShowNum(95,16,setData.chUpper[1],4,16,1);
	
	OLED_ShowString(2,32, (u8 *)"T:",16,1);
	OLED_ShowNum(18,32,setData.chLower[2],4,16,1);
	OLED_ShowNum(56,32,setData.chMiddle[2],4,16,1);
	OLED_ShowNum(95,32,setData.chUpper[2],4,16,1);
	
	OLED_ShowString(2,48, (u8 *)"R:",16,1);
	OLED_ShowNum(18,48,setData.chLower[3],4,16,1);
	OLED_ShowNum(56,48,setData.chMiddle[3],4,16,1);
	OLED_ShowNum(95,48,setData.chUpper[3],4,16,1);
}// Tertiary menu: Channel 1-4 display

void menu_hfccTip(void){
	OLED_Clear_GRAM();//OLED CLEAR GRAM
	OLED_ShowString(28,32, (u8 *)"PRESS Enter",12,1);	
}// Tertiary menu: Restore to default
void menu_hfcg(void){
	OLED_Clear_GRAM();//OLED CLEAR GRAM
	resetData();// Reset data
	STMFLASH_Write(FLASH_SAVE_ADDR,(u16 *)&setData,setDataSize);// Write to FLASH
	OLED_ShowString(24,32, (u8 *)"SUCCESSFULLY!",12,1);
}// Third-level menu: Recovery successful

void menu_gybjInf(void){
	OLED_Clear_GRAM();//OLED CLEAR GRAM
	OLED_ShowString(4,16, (u8 *)"BY MR AHSAN",16,1);
	OLED_ShowString(4,32, (u8 *)"AND CAIZI.",16,1);
	OLED_ShowString(4,48, (u8 *)"V2.4",16,1);
	
}// Third-level menu: J20RC Development Team - V2.0
// User-editable menu page
u16 menus[43] = {
	tdwt1,// Second-level menu: Channel 1
	tdwt2,// Second-level menu: Channel 2
	tdwt3,// Second-level menu: Channel 3
	tdwt4,// Second-level menu: Channel 4
	tdwt5,// Second-level menu: Channel 5
	tdwt6,// Second-level menu: Channel 6
	tdwt7,// Second-level menu: Channel 7
	tdwt8,// Second-level menu: Channel 8
	
	tdzf1,// Second-level menu: Channel 1
	tdzf2,// Second-level menu: Channel 2
	tdzf3,// Second-level menu: Channel 3
	tdzf4,// Second-level menu: Channel 4
	tdzf5,// Second-level menu: Channel 5
	tdzf6,// Second-level menu: Channel 6
	tdzf7,// Second-level menu: Channel 7
	tdzf8,// Second-level menu: Channel 8
	
	xjjs,// Second-level menu: New Receive
	xzmx,// Second-level menu: Select Model
	bcmx,// Second-level menu: Save Model
	txmm,// Second-level menu: Communication Password
	
	ppmsc,// Second-level menu: PPM Output
	wxfs,// Second-level menu: Wireless Transmission
	fsgl,// Second-level menu: Transmission Power
	
	tdys1,// Second-level menu: Channel 1
	tdys2,// Second-level menu: Channel 2
	tdys3,// Second-level menu: Channel 3
	tdys4,// Second-level menu: Channel 4
	tdys5,// Second-level menu: Channel 5
	tdys6,// Second-level menu: Channel 6
	tdys7,// Second-level menu: Channel 7
	tdys8,// Second-level menu: Channel 8
	
	wtdw,// Third-level menu: Fine-tuning Unit
	ajyx,// Third-level menu: Key Sound Effects
	kjhm,// Third-level menu: Boot Screen
	
	dyjz,// Third-level menu: Voltage Calibration
	bjdy,// Third-level menu: Alarm Voltage
	jsbj,// Third-level menu: Reception Alarm
	
	nzbj,// Third-level menu: Alarm Clock
	nzsc,// Third-level menu: Alarm Duration
	kjzj,// Third-level menu: Boot Self-Check
	
	ymph,// Third-level menu: Throttle Preference
	ymqx,// Third-level menu: Throttle Curve
	skbh,// Third-level menu: Loss of Control Protection
};
/*
Determine if the menu index is a user-editable page
Return: 1 for yes, 0 for no
*/
u16 IsInKeyMenu(u16 num)
{
	int thisindex = -1;
	u16 i;
	for(i=0; i<43; i++)
	{
		if(menus[i] == num)
		{
			thisindex = i;
			break;
		}
		else if(menus[i] > num)
		{
			break;
		}
	}
	if(thisindex < 0) return 0;
	else return 1;
}

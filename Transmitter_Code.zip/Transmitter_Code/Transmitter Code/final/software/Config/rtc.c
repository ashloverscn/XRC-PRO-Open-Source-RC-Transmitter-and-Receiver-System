#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "rtc.h"
// Mini STM32 development board
// RTC real-time clock driver code
// ALIENTEK@ALIENTEK
// June 6, 2010

_calendar_obj calendar; // Clock structure

static void RTC_NVIC_Config(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn; // RTC global interrupt
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; // Preemptive priority 1 bit, Sub-priority 3 bits
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0; // Preemptive priority 0 bit, Sub-priority 4 bits
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; // Enable this channel interrupt
    NVIC_Init(&NVIC_InitStructure); // Initialize the NVIC register according to the parameters specified in NVIC_InitStruct
}

// Real-time clock configuration
// Initialize the RTC clock and check if the clock is working properly
// BKP->DR1 is used to save the setting of whether it is the first configuration
// Returns 0: normal
// Others: error code

u8 RTC_Init(void)
{
    // Check if it is the first time to configure the clock
    u8 temp = 0;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE); // Enable PWR and BKP peripheral clocks
    PWR_BackupAccessCmd(ENABLE); // Enable backup register access
    if (BKP_ReadBackupRegister(BKP_DR1) != 0x5050) // Read data from the specified backup register: read data that does not match what was written
    {
        BKP_DeInit(); // Reset backup area
        RCC_LSEConfig(RCC_LSE_ON); // Set external low-speed crystal oscillator (LSE), use external low-speed crystal oscillator
        while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET && temp < 250) // Check if the specified RCC flag is set, wait for the low-speed crystal oscillator to be ready
        {
            temp++;
            delay_ms(10);
        }
        if (temp >= 250)
            return 1; // Clock initialization failed, crystal oscillator has a problem
        RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE); // Set RTC clock (RTCCLK), select LSE as RTC clock
        RCC_RTCCLKCmd(ENABLE); // Enable RTC clock
        RTC_WaitForLastTask(); // Wait for the last write operation to RTC registers to finish
        RTC_WaitForSynchro(); // Wait for RTC register synchronization
        RTC_ITConfig(RTC_IT_SEC, ENABLE); // Enable RTC second interrupt
        RTC_WaitForLastTask(); // Wait for the last write operation to RTC registers to finish
        RTC_EnterConfigMode(); // Allow configuration
        RTC_SetPrescaler(32767); // Set the value of RTC prescaler
        RTC_WaitForLastTask(); // Wait for the last write operation to RTC registers to finish
        RTC_Set(2024, 6, 25, 02, 9, 55); // Set the time
        RTC_ExitConfigMode(); // Exit configuration mode
        BKP_WriteBackupRegister(BKP_DR1, 0X5050); // Write user program data to the specified backup register
    }
    else // Continue timing
    {
        RTC_WaitForSynchro(); // Wait for the last write operation to RTC registers to finish
        RTC_ITConfig(RTC_IT_SEC, ENABLE); // Enable RTC second interrupt
        RTC_WaitForLastTask(); // Wait for the last write operation to RTC registers to finish
    }
    RTC_NVIC_Config(); // RTC interrupt grouping settings
    RTC_Get(); // Update time
    return 0; // ok
}

// RTC clock interrupt
// Triggered every second
// extern u16 tcnt;
void RTC_IRQHandler(void)
{
    if (RTC_GetITStatus(RTC_IT_SEC) != RESET) // Second interrupt
    {
        RTC_Get(); // Update time
    }
    if (RTC_GetITStatus(RTC_IT_ALR) != RESET) // Alarm interrupt
    {
        RTC_ClearITPendingBit(RTC_IT_ALR); // Clear alarm interrupt
        RTC_Get(); // Update time
        printf("Alarm Time:%d-%d-%d %d:%d:%d\n", calendar.w_year, calendar.w_month, calendar.w_date, calendar.hour, calendar.min, calendar.sec); // Output alarm time
    }
    RTC_ClearITPendingBit(RTC_IT_SEC | RTC_IT_OW); // Clear alarm interrupt
    RTC_WaitForLastTask();
}

// Determine if it is a leap year function
// Month   1  2  3  4  5  6  7  8  9  10 11 12
// Leap year   31 29 31 30 31 30 31 31 30 31 30 31
// Non-leap year 31 28 31 30 31 30 31 31 30 31 30 31
// Input: year
// Output: whether the year is a leap year. 1, yes. 0, no
u8 Is_Leap_Year(u16 year)
{
    if (year % 4 == 0) // Must be divisible by 4
    {
        if (year % 100 == 0)
        {
            if (year % 400 == 0)
                return 1; // If ending with 00, must also be divisible by 400
            else
                return 0;
        }
        else
            return 1;
    }
    else
        return 0;
}

// Set clock
// Convert the input clock to seconds
// Based on January 1, 1970
// Legal years are from 1970 to 2099
// Return value: 0, success; others: error code.
// Month data table
u8 const table_week[12] = {0, 3, 3, 6, 1, 4, 6, 2, 5, 0, 3, 5}; // Month correction data table
// Regular year month date table
const u8 mon_table[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
u8 RTC_Set(u16 syear, u8 smon, u8 sday, u8 hour, u8 min, u8 sec)
{
    u16 t;
    u32 seccount = 0;
    if (syear < 1970 || syear > 2099)
        return 1;
    for (t = 1970; t < syear; t++) // Add up all the years' seconds
    {
        if (Is_Leap_Year(t))
            seccount += 31622400; // Leap year seconds
        else
            seccount += 31536000; // Regular year seconds
    }
    smon -= 1;
    for (t = 0; t < smon; t++) // Add up the seconds of the previous months
    {
        seccount += (u32)mon_table[t] * 86400; // Add month seconds
        if (Is_Leap_Year(syear) && t == 1)
            seccount += 86400; // Add one day's seconds for leap year February
    }
    seccount += (u32)(sday - 1) * 86400; // Add up the seconds of the previous dates
    seccount += (u32)hour * 3600; // Add hours' seconds
    seccount += (u32)min * 60; // Add minutes' seconds
    seccount += sec; // Add seconds

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE); // Enable PWR and BKP peripheral clocks
    PWR_BackupAccessCmd(ENABLE); // Enable RTC and backup register access
    RTC_SetCounter(seccount); // Set the value of RTC counter

    RTC_WaitForLastTask(); // Wait for the last write operation to RTC registers to finish
    return 0;
}

// Initialize alarm
// Based on January 1, 1970
// Legal years are from 1970 to 2099
// syear, smon, sday, hour, min, sec: alarm year, month, day, hour, minute, second
// Return value: 0, success; others: error code.
u8 RTC_Alarm_Set(u16 syear, u8 smon, u8 sday, u8 hour, u8 min, u8 sec)
{
    u16 t;
    u32 seccount = 0;
    if (syear < 1970 || syear > 2099)
        return 1;
    for (t = 1970; t < syear; t++) // Add up all the years' seconds
    {
        if (Is_Leap_Year(t))
            seccount += 31622400; // Leap year seconds
        else
            seccount += 31536000; // Regular year seconds
    }
    smon -= 1;
    for (t = 0; t < smon; t++) // Add up the seconds of the previous months
    {
        seccount += (u32)mon_table[t] * 86400; // Add month seconds
        if (Is_Leap_Year(syear) && t == 1)
            seccount += 86400; // Add one day's seconds for leap year February
    }
    seccount += (u32)(sday - 1) * 86400; // Add up the seconds of the previous dates
    seccount += (u32)hour * 3600; // Add hours' seconds
    seccount += (u32)min * 60; // Add minutes' seconds
    seccount += sec; // Add seconds
    // Set clock
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE); // Enable PWR and BKP peripheral clocks
    PWR_BackupAccessCmd(ENABLE); // Enable backup register access
    // The three steps above are necessary!
    RTC_SetAlarm(seccount);
    RTC_WaitForLastTask(); // Wait for the last write operation to RTC registers to finish
    return 0;
}

// Get the current time
// Return value: 0, success; others: error code.
u8 RTC_Get(void)
{
    static u16 daycnt = 0;
    u32 timecount = 0;
    u32 temp = 0;
    u16 temp1 = 0;
    timecount = RTC_GetCounter();
    temp = timecount / 86400; // Get the number of days (corresponding to seconds)
    if (daycnt != temp) // More than one day has passed
    {
        daycnt = temp;
        temp1 = 1970; // Start from 1970
        while (temp >= 365)
        {
            if (Is_Leap_Year(temp1)) // Is it a leap year
            {
                if (temp >= 366)
                    temp -= 366; // Leap year seconds
                else
                {
                    temp1++;
                    break;
                }
            }
            else
                temp -= 365; // Regular year
            temp1++;
        }
        calendar.w_year = temp1; // Get the year
        temp1 = 0;
        while (temp >= 28) // More than a month has passed
        {
            if (Is_Leap_Year(calendar.w_year) && temp1 == 1) // Is it a leap year / February
            {
                if (temp >= 29)
                    temp -= 29; // Leap year seconds
                else
                    break;
            }
            else
            {
                if (temp >= mon_table[temp1])
                    temp -= mon_table[temp1]; // Regular year
                else
                    break;
            }
            temp1++;
        }
        calendar.w_month = temp1 + 1; // Get the month
        calendar.w_date = temp + 1; // Get the date
    }
    temp = timecount % 86400; // Get the seconds
    calendar.sumsec = temp; // All seconds
    calendar.hour = temp / 3600; // Hours
    calendar.min = (temp % 3600) / 60; // Minutes
    calendar.sec = (temp % 3600) % 60; // Seconds
    calendar.week = RTC_Get_Week(calendar.w_year, calendar.w_month, calendar.w_date); // Get the week
    return 0;
}

// Get the current day of the week
// Function description: Get the week from the input Gregorian date (only allowed from 1901 to 2099)
// Input parameters: Gregorian year, month, day
// Return value: day of the week
u8 RTC_Get_Week(u16 year, u8 month, u8 day)
{
    u16 temp2;
    u8 yearH, yearL;

    yearH = year / 100;
    yearL = year % 100;
    // If it's the 21st century, add 100 to the year number
    if (yearH > 19)
        yearL += 100;
    // Only count leap years after 1900
    temp2 = yearL + yearL / 4;
    temp2 = temp2 % 7;
    temp2 = temp2 + day + table_week[month - 1];
    if (yearL % 4 == 0 && month < 3)
        temp2--;
    return (temp2 % 7);
}

#include "nrf24l01.h"
#include "delay.h"
#include "spi.h"
#include "usart.h"
#include "adc.h"
#include "main.h"

	
const u8 TX_ADDRESS[TX_ADR_WIDTH]={0x34,0x43,0x10,0x10,0x01}; 
const u8 RX_ADDRESS[RX_ADR_WIDTH]={0x34,0x43,0x10,0x10,0x01};




/*=======================================================
* Function: void NRF24L01_Init(void)
* Purpose: Initializes the NRF24L01 module
* Parameters: None
* Return value: None
* Remarks: Corresponding GPIO settings
=======================================================*/

void NRF24L01_Init(void)
{ 	
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef  SPI_InitStructure;

	// Enable clock for GPIOA, GPIOB, and GPIOC
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE); // Enable PB, G port clock

#ifdef NRF_PIN
/* Connections for V2.0 version PCB */
GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;                  // PB12 push-pull
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;            // Push-pull output
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOB, &GPIO_InitStructure);                       // Initialize PB12 as push-pull output - NRF_CSN

GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;                   
GPIO_Init(GPIOA, &GPIO_InitStructure);                       // Initialize PA8 as push-pull output - NRF_CE

GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9;                   
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;               // PA9 interrupt pull-down input - NRF_IRQ  
GPIO_Init(GPIOA, &GPIO_InitStructure);                       
#else
/* Connections for V1.0 version PCB */
GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;            // Initialize PA8 as push-pull output - NRF_CSN
GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
GPIO_Init(GPIOA, &GPIO_InitStructure);                       // Initialize PA8 as push-pull output - NRF_CSN

GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;                   
GPIO_Init(GPIOA, &GPIO_InitStructure);                       // Initialize PA9 as push-pull output - NRF_CE

GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;                  
GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;               // PB12 interrupt pull-down input - NRF_IRQ  
GPIO_Init(GPIOB, &GPIO_InitStructure);
#endif

// Reset bits for PA8, PA9 (pull down)
GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_9); // PA8,9 pull down
GPIO_ResetBits(GPIOB, GPIO_Pin_12); // PB12 pull down

// Initialize SPI
SPI2_Init();    

// Disable the SPI peripheral; first turn off SPI before making configurations
SPI_Cmd(SPI2, DISABLE);

// Configure SPI settings
SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex; // Set SPI to two-line full-duplex mode
SPI_InitStructure.SPI_Mode = SPI_Mode_Master;                      // Set SPI as Master mode
SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;                 // Set data frame size to 8 bits for transmission and reception
SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;                         // Clock idle state is low (0)
SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;                      // Data capture on the first clock edge (0)
SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;                         // NSS signal is controlled by software
SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16; // Set baud rate prescaler value: 16
SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;                // Data transmission starts from the Most Significant Bit (MSB)
SPI_InitStructure.SPI_CRCPolynomial = 7;                          // CRC polynomial used for CRC value calculation
SPI_Init(SPI2, &SPI_InitStructure);                                // Initialize the SPI peripheral with specified parameters

// Enable the SPI peripheral
SPI_Cmd(SPI2, ENABLE);

// Enable NRF24L01; when CSN is low, CE works with the CONFIG register of NRF24L01 to determine its state
NRF24L01_CE = 0;           // Set CE low
NRF24L01_CSN = 1;          // Deselect the SPI chip; it operates when CSN is low
	 		 	 
}
/*=======================================================
* Function: u8 NRF24L01_Check(void)
* Purpose: Check if the NRF24L01 module is present
* Parameters: None
* Return Value: 0: Success; 1: Failure
* Remarks: Write 5 bytes of data to the NRF24L01's transmit address register and read it back
*          to determine if the 24L01 is functioning correctly
=======================================================*/
u8 NRF24L01_Check(void)
{
    u8 buf[5] = {0xA5, 0xA5, 0xA5, 0xA5, 0xA5}; // Prepare a buffer filled with 0xA5
    u8 i;
    SPI2_SetSpeed(SPI_BaudRatePrescaler_4); // Set SPI speed to 9 MHz (maximum SPI clock for 24L01 is 10 MHz)
    
    // Write 5 bytes of the address to the TX_ADDR register
    NRF24L01_Write_Buf(NRF_WRITE_REG + TX_ADDR, buf, 5);
    
    // Read back the address from the TX_ADDR register
    NRF24L01_Read_Buf(TX_ADDR, buf, 5);
    
    // Check if the read values match the expected values
    for(i = 0; i < 5; i++) {
        if(buf[i] != 0xA5) break; // If any byte does not match, break the loop
    }
    
    // If not all bytes matched, return 1 (indicating an error with the NRF24L01)
    if(i != 5) return 1; // Error detected
    
    return 0; // NRF24L01 detected successfully
}

/*=======================================================
* Function: u8 NRF24L01_Write_Reg(u8 reg, u8 value)
* Purpose: Write one byte of data to a register
* Parameters: 
*   reg: Register address
*   value: Value to be written
* Return value: 
*   status: Value read from the register status
=======================================================*/

u8 NRF24L01_Write_Reg(u8 reg, u8 value)
{
    u8 status;	
    NRF24L01_CSN = 0;                // Enable SPI transmission
    status = SPI2_ReadWriteByte(reg); // Send the register address
    SPI2_ReadWriteByte(value);       // Write the value to the register
    NRF24L01_CSN = 1;                // Disable SPI transmission	   
    return(status);                   // Return the status value
}

/*=======================================================
* Function: u8 NRF24L01_Read_Reg(u8 reg)
* Purpose: Read one byte of data from a register
* Parameters: reg: Register address
* Return Value: reg_val: Read value
=======================================================*/

u8 NRF24L01_Read_Reg(u8 reg)
{
	u8 reg_val;	    
 	NRF24L01_CSN = 0;          // Enable SPI transmission		
  	SPI2_ReadWriteByte(reg);   // Send the register address
  	reg_val = SPI2_ReadWriteByte(0XFF); // Read the register content
  	NRF24L01_CSN = 1;          // Disable SPI transmission		    
  	return(reg_val);           // Return the read value
}

/*=======================================================
* Function: u8 NRF24L01_Read_Buf(u8 reg, u8 *pBuf, u8 len)
* Purpose: Read a certain length of data from a specified location
* Parameters: reg: specified location; *pBuf: pointer to the start address of the specified data; len: length of the data
* Return value: status: status of the register
=======================================================*/

u8 NRF24L01_Read_Buf(u8 reg, u8 *pBuf, u8 len)
{
    u8 status, u8_ctr;       
    NRF24L01_CSN = 0;           // Enable SPI transmission
    status = SPI2_ReadWriteByte(reg); // Send the register value (address) and read the status value
    for (u8_ctr = 0; u8_ctr < len; u8_ctr++) 
        pBuf[u8_ctr] = SPI2_ReadWriteByte(0xFF); // Read out the data
    NRF24L01_CSN = 1;       // Disable SPI transmission
    return status;         // Return the read status value
}

/*=======================================================
* Function: u8 NRF24L01_Write_Buf(u8 reg, u8 *pBuf, u8 len)
* Purpose: Write a specified length of data to a designated location
* Parameters: reg: specified location; *pBuf: address of the data to be written; len: data length
* Return Value: status: status of the register
=======================================================*/
u8 NRF24L01_Write_Buf(u8 reg, u8 *pBuf, u8 len)
{
    u8 status, u8_ctr;	    
    NRF24L01_CSN = 0;          // Enable SPI transmission
    status = SPI2_ReadWriteByte(reg); // Send register value (address) and read status value
    for (u8_ctr = 0; u8_ctr < len; u8_ctr++) 
        SPI2_ReadWriteByte(*pBuf++); // Write data	 
    NRF24L01_CSN = 1;       // Disable SPI transmission
    return status;          // Return the read status value
}	

/*=======================================================
* Function: u8 NRF24L01_TxPacket(u8 *txbuf)
* Purpose: Send data using NRF24L01
* Parameters: *txbuf: address of the data to be sent
* Return Value: MAX_TX: maximum retransmission count; TX_OK: sending completed; 0xFF: sending failed
=======================================================*/
u8 NRF24L01_TxPacket(u8 *txbuf)
{
    u8 sta;
    SPI2_SetSpeed(SPI_BaudRatePrescaler_8); // SPI speed is set to 9MHz (the maximum SPI clock for 24L01 is 10MHz)   
    NRF24L01_CE = 0;
    NRF24L01_Write_Buf(WR_TX_PLOAD, txbuf, TX_PLOAD_WIDTH); // Write data to the transmission FIFO buffer, TXBUF has 32 bytes
    NRF24L01_CE = 1; // Start sending	   
    // while(NRF24L01_IRQ != 0); // Wait for sending to complete
    sta = NRF24L01_Read_Reg(STATUS); // Read the value of the status register	   
    NRF24L01_Write_Reg(NRF_WRITE_REG + STATUS, sta); // Clear TX_DS or MAX_RT interrupt flag
    // return TX_OK; // Regardless of success or failure, continue sending data
    if (sta & MAX_TX) // Reached maximum retransmission count
    {
        NRF24L01_Write_Reg(FLUSH_TX, 0xff); // Clear TX FIFO register 
        return MAX_TX; 
    }
    if (sta & TX_OK) // Sending completed
    {
        return TX_OK;
    }
    return 0xff; // Other reasons for sending failure
}

/*=======================================================
* Function: u8 NRF24L01_RxPacket(u8 *rxbuf)
* Purpose: Receive data using NRF24L01
* Parameters: *rxbuf: address to store the received data
* Return Value: 0: reception successful; 1: reception failed
=======================================================*/
u8 NRF24L01_RxPacket(u8 *rxbuf)
{
    u8 sta;		    							   
    SPI2_SetSpeed(SPI_BaudRatePrescaler_8); // SPI speed is set to 9MHz (the maximum SPI clock for 24L01 is 10MHz)   
    sta = NRF24L01_Read_Reg(STATUS);  // Read the value of the status register    	 
    NRF24L01_Write_Reg(NRF_WRITE_REG + STATUS, sta); // Clear TX_DS or MAX_RT interrupt flag
    if (sta & RX_OK) // Data received
    {
        NRF24L01_Read_Buf(RD_RX_PLOAD, rxbuf, RX_PLOAD_WIDTH); // Read data
        NRF24L01_Write_Reg(FLUSH_RX, 0xff); // Clear RX FIFO register 
        return 0; 
    }	   
    return 1; // No data received
}	

/*=======================================================
* Function: void NRF24L01_RX_Mode(void)
* Purpose: Configure NRF24L01 for receive mode
* Parameters: None
* Return Value: None
* Note: Set RX address, write RX data width, select RF channel, baud rate, and LNA HCURR.
*        When CE goes high, enter RX mode and data can be received.
=======================================================*/ 
void NRF24L01_RX_Mode(void)
{
    NRF24L01_CE = 0;	  
    NRF24L01_Write_Buf(NRF_WRITE_REG + RX_ADDR_P0, (u8*)RX_ADDRESS, RX_ADR_WIDTH); // Write RX node address
	  
    NRF24L01_Write_Reg(NRF_WRITE_REG + EN_AA, 0x01);    // Enable auto acknowledgment for channel 0    
    NRF24L01_Write_Reg(NRF_WRITE_REG + EN_RXADDR, 0x01); // Enable receive address for channel 0  	 
    NRF24L01_Write_Reg(NRF_WRITE_REG + RF_CH, 40);	     // Set RF communication frequency		  
    NRF24L01_Write_Reg(NRF_WRITE_REG + RX_PW_P0, RX_PLOAD_WIDTH); // Set valid data width for channel 0 	    
    NRF24L01_Write_Reg(NRF_WRITE_REG + RF_SETUP, 0x0f); // Set TX transmission parameters, 0dB gain, 2Mbps, low noise gain enabled   
    NRF24L01_Write_Reg(NRF_WRITE_REG + CONFIG, 0x0f); // Configure basic operating parameters; PWR_UP, EN_CRC, 16BIT_CRC, receive mode 
    NRF24L01_CE = 1; // CE goes high, enter receive mode 
}	

/*=======================================================
* Function: void NRF24L01_TX_Mode(void)
* Purpose: Configure NRF24L01 for transmit mode
* Parameters: power: Transmission power //0x0f=0dBm;0x0d=-6dBm;0xb=-12dBm;0x09=-18dBm; higher power means higher dBm
* Return Value: None
* Note: Set TX address, write TX data width, set the RX acknowledgment address,
*       fill TX data to be sent, select RF channel, baud rate, and LNA HCURR.
*       PWR_UP, enable CRC, and if CE is high for more than 10us, then start transmission.
=======================================================*/ 

void NRF24L01_TX_Mode(u8 power)
{														 
    NRF24L01_CE = 0;	    
    NRF24L01_Write_Buf(NRF_WRITE_REG + TX_ADDR, (u8*)TX_ADDRESS, TX_ADR_WIDTH); // Write TX node address 
    NRF24L01_Write_Buf(NRF_WRITE_REG + RX_ADDR_P0, (u8*)RX_ADDRESS, RX_ADR_WIDTH); // Set TX node address, mainly to enable ACK	  

    NRF24L01_Write_Reg(NRF_WRITE_REG + EN_AA, 0x01);     // Enable auto acknowledgment for channel 0    
    NRF24L01_Write_Reg(NRF_WRITE_REG + EN_RXADDR, 0x01); // Enable receive address for channel 0  
    NRF24L01_Write_Reg(NRF_WRITE_REG + SETUP_RETR, 0x1a); // Set automatic retransmission interval: 500us + 86us; max retransmission count: 10 times
    NRF24L01_Write_Reg(NRF_WRITE_REG + RF_CH, 40);       // Set RF channel to 40
    NRF24L01_Write_Reg(NRF_WRITE_REG + RF_SETUP, power);  // Set TX transmission parameters, 0dB gain, 2Mbps, low noise gain enabled   
    NRF24L01_Write_Reg(NRF_WRITE_REG + CONFIG, 0x0e);    // Configure basic operating parameters; PWR_UP, EN_CRC, 16BIT_CRC, receive mode, enable all interrupts
    NRF24L01_CE = 1; // CE goes high, start transmission after 10us
}

/*
  * Function Purpose: Enter low power mode for NRF24L01
*/
void NRF24L01_LowPower_Mode(void)
{
    NRF24L01_CE = 0; // Disable NRF
    NRF24L01_Write_Reg(NRF_WRITE_REG + CONFIG, 0x0c); // Configure operating mode: Power-down mode
}

u8 sendDataPacket(void)
{
    u8 chPacket[32]; // Data packet to be sent
    u16 t = 0;
    u8 sendIsOK; // Indicate whether the sending was successful

    for(t = 0; t < 16; t++)
    {
        if(t == 0) // Add header 00
        {
            chPacket[2*t] = 0x00;
            chPacket[2*t + 1] = 0x00;
        }
        else if(t <= chNum)
        {
            chPacket[2*t] = (u8)(PWMvalue[t - 1] >> 8) & 0xFF; // High 8 bits, split u16 into two u8 for transmission
            chPacket[2*t + 1] = (u8)PWMvalue[t - 1] & 0xFF; // Low 8 bits
        }
        else
        {
            chPacket[2*t] = 0xFF;
            chPacket[2*t + 1] = 0xFF;
        }
    } 
    sendIsOK = NRF24L01_TxPacket(chPacket); // Send the data packet
    return sendIsOK; // Return sending status
}

// Main function to get signal strength
int getSignalStrength(void)
{
    const int totalPackets = 40;  // Number of packets to send for the test
    int successfulPackets = 0;

    if (setData.NRF_Mode == ON) 
    {
        NRF24L01_TX_Mode(setData.NRF_Power); // Transmit mode
    }
    else 
    {
        NRF24L01_LowPower_Mode(); // Power-down mode
    } 

    // Send multiple packets and count successful transmissions
    for (int i = 0; i < totalPackets; i++)
    {
        if (sendDataPacket() == TX_OK)
        {
            successfulPackets++;
        }
        delay_us(700); // Wait for 700 microseconds between packets
    }

    // Calculate the signal strength as a percentage of successful transmissions
    int signalStrength = (successfulPackets * 100) / totalPackets;
    return signalStrength; // Return the calculated signal strength
}







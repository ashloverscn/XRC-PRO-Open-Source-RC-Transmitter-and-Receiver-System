#ifndef __24L01_H
#define __24L01_H	 		  
#include "sys.h"   




// NRF24L01 register operation commands
#define NRF_READ_REG    0x00  // Read configuration register, with the lower 5 bits as the register address
#define NRF_WRITE_REG   0x20  // Write configuration register, with the lower 5 bits as the register address
#define RD_RX_PLOAD     0x61  // Read valid RX data, 1~32 bytes
#define WR_TX_PLOAD     0xA0  // Write valid TX data, 1~32 bytes
#define FLUSH_TX        0xE1  // Clear TX FIFO register. Used in transmit mode.
#define FLUSH_RX        0xE2  // Clear RX FIFO register. Used in receive mode.
#define REUSE_TX_PL     0xE3  // Reuse the last packet of data. CE is high, and the data packet is continuously transmitted.
#define NOP             0xFF  // No operation, can be used to read status register

// SPI (NRF24L01) register addresses
#define CONFIG          0x00  // Configuration register address; bit0: 1 receive mode, 0 transmit mode; bit1: power selection; bit2: CRC mode; bit3: CRC enable;
                              // bit4: interrupt MAX_RT (maximum retransmission interrupt) enable; bit5: interrupt TX_DS enable; bit6: interrupt RX_DR enable
#define EN_AA           0x01  // Enable auto-acknowledgment feature for channels 0~5 (bits 0~5)
#define EN_RXADDR       0x02  // Receive address enable for channels 0~5 (bits 0~5)
#define SETUP_AW        0x03  // Set address width for all data channels: bit1,0: 00 = 3 bytes; 01 = 4 bytes; 02 = 5 bytes;
#define SETUP_RETR      0x04  // Set up automatic retransmission; bit3: 0, automatic retransmission counter; bit7:4, automatic retransmission delay 250*x+86us
#define RF_CH           0x05  // RF channel, bit6:0, working channel frequency;
#define RF_SETUP        0x06  // RF register; bit3: transmission rate (0: 1Mbps, 1: 2Mbps); bit2: transmission power; bit0: low noise amplifier gain
                                // 0x06 = 0dBm; 0x04 = -6dBm; 0x02 = -12dBm; 0x00 = -18dBm; higher power means higher dBm
#define STATUS          0x07  // Status register; bit0: TX FIFO full flag; bit3: 1, received data channel number (maximum: 6); bit4: maximum retransmissions reached
                              // bit5: data transmission complete interrupt; bit6: data reception interrupt

#define MAX_TX         0x10  // Maximum transmission count interrupt
#define TX_OK          0x20  // TX transmission complete interrupt
#define RX_OK          0x40  // Data received interrupt

#define OBSERVE_TX      0x08  // Transmission observation register; bit7:4, packet loss counter; bit3:0, retransmission counter
#define CD              0x09  // Carrier detection register; bit0, carrier detected;
#define RX_ADDR_P0      0x0A  // Data channel 0 receive address, maximum length of 5 bytes, low byte first
#define RX_ADDR_P1      0x0B  // Data channel 1 receive address, maximum length of 5 bytes, low byte first
#define RX_ADDR_P2      0x0C  // Data channel 2 receive address, lowest byte can be set, high byte must equal RX_ADDR_P1[39:8];
#define RX_ADDR_P3      0x0D  // Data channel 3 receive address, lowest byte can be set, high byte must equal RX_ADDR_P1[39:8];
#define RX_ADDR_P4      0x0E  // Data channel 4 receive address, lowest byte can be set, high byte must equal RX_ADDR_P1[39:8];
#define RX_ADDR_P5      0x0F  // Data channel 5 receive address, lowest byte can be set, high byte must equal RX_ADDR_P1[39:8];
#define TX_ADDR         0x10  // Transmission address (low byte first), in ShockBurstTM mode, RX_ADDR_P0 equals this address
#define RX_PW_P0        0x11  // Valid data width for receiving data channel 0 (1~32 bytes), setting to 0 is illegal
#define RX_PW_P1        0x12  // Valid data width for receiving data channel 1 (1~32 bytes), setting to 0 is illegal
#define RX_PW_P2        0x13  // Valid data width for receiving data channel 2 (1~32 bytes), setting to 0 is illegal
#define RX_PW_P3        0x14  // Valid data width for receiving data channel 3 (1~32 bytes), setting to 0 is illegal
#define RX_PW_P4        0x15  // Valid data width for receiving data channel 4 (1~32 bytes), setting to 0 is illegal
#define RX_PW_P5        0x16  // Valid data width for receiving data channel 5 (1~32 bytes), setting to 0 is illegal
#define NRF_FIFO_STATUS 0x17  // FIFO status register; bit0, RX FIFO register empty flag; bit1, RX FIFO full flag; bit2,3, reserved
                              // bit4, TX FIFO empty flag; bit5, TX FIFO full flag; bit6, 1, cycle sending the last data packet; 0, do not cycle;

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// NRF24L01 operation pin configurations
#ifdef NRF_PIN
/* V2.0 PCB wiring */
#define NRF24L01_CE   PAout(8) // NRF24L01 chip enable signal
#define NRF24L01_CSN  PBout(12) // SPI chip select signal
#define NRF24L01_IRQ  PAin(9)  // IRQ host data input
#else
/* V1.0 PCB wiring */
#define NRF24L01_CE   PAout(9) // NRF24L01 chip enable signal output
#define NRF24L01_CSN  PAout(8) // SPI chip select signal output
#define NRF24L01_IRQ  PBin(12)  // IRQ host data input
#endif

// NRF24L01 data width definitions
#define TX_ADR_WIDTH    5   	// 5 bytes address width
#define RX_ADR_WIDTH    5   	// 5 bytes address width
#define TX_PLOAD_WIDTH  32  	// 32 bytes user data width
#define RX_PLOAD_WIDTH  32  	// 32 bytes user data width
#define CHECK_PAYLOAD "CHECK"  // A simple payload for connection check
#define CHECK_PAYLOAD_LEN 5

// Function declarations
int getSignalStrength(void);
void NRF24L01_Init(void);						// Initialization
void NRF24L01_RX_Mode(void);					// Configure as receive mode
void NRF24L01_TX_Mode(u8 power);					// Configure as transmit mode
void NRF24L01_LowPower_Mode(void);				// Configure as low-power mode
u8 NRF24L01_Write_Buf(u8 reg, u8 *pBuf, u8 u8s);// Write data buffer
u8 NRF24L01_Read_Buf(u8 reg, u8 *pBuf, u8 u8s);	// Read data buffer		  
u8 NRF24L01_Read_Reg(u8 reg);					// Read register
u8 NRF24L01_Write_Reg(u8 reg, u8 value);		// Write register
u8 NRF24L01_Check(void);						// Check if NRF24L01 exists
u8 NRF24L01_TxPacket(u8 *txbuf);				// Send a data packet
u8 NRF24L01_RxPacket(u8 *rxbuf);				// Receive a data packet
u8 sendDataPacket(void);// Send data packet

#endif



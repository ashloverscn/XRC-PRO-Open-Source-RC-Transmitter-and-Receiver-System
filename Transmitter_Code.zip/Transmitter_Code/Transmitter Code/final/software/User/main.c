
#include "main.h"
#define MIN_VOLTAGE 3.2
#define MAX_VOLTAGE 4.2
#define MAX_FILL_PIXELS 16
#define REFRESH_INTERVAL 1000
typedef int bool;
#define true 1
#define false 0

#define SIGNAL_SAMPLES 5 // Number of samples for moving average

/* Function Prototypes */
void keyEventHandle(void);
void menuEventHandle(void);
void addSignalStrengthSample(int newSample);
int getAverageSignalStrength(void);
void displaySignalIcon(int strength);
void updateSignalStrength(void);

/* Variables */
extern unsigned char logo[];
extern unsigned char iconClock[];
extern unsigned char iconAlarm[];
extern unsigned char iconSignal100[];
extern unsigned char iconSignal75[];
extern unsigned char iconSignal50[];
extern unsigned char iconSignal25[];
extern unsigned char iconSignalOff[];

u16 loca; // Coordinates
u16 thrNum; // Throttle value
extern char timeStr[9]; // Time string
extern float percentage;
u16 loopCount = 0; // Loop counter
u16 clockCount = 0;
int fillPixels;
int signalStrengthSamples[SIGNAL_SAMPLES] = {0};
int currentSampleIndex = 0;
bool previouslyConnected = false;

/* Setup Function */
void setup(void) {
    delay_init(); // Initialize delay
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); // Set NVIC priority group
    usart_init(115200); // Initialize USART1 with baud rate 115200
    TIM2_Init(1999, 71); // Initialize Timer 2
    TIM3_Init(19999, 71); // Initialize Timer 3
    DMA1_Init(); // Initialize DMA1
    ADC_Pin_Init(); // Initialize ADC pins
    SET_Init(); // Read user data
    RTC_Init(); // Initialize RTC
    BEEPER_Init(); // Initialize beeper
    KEY_Init(); // Initialize keys
    NRF24L01_Init(); // Initialize NRF24L01
    PPM_Init(); // Initialize PPM pins
    
    beeperOnce(20); // Beep once
    OLED_Init(); // Initialize OLED
    OLED_Clear();
    OLED_DrawPointBMP(0, 0, logo, 128, 64, setData.onImage); // Display logo
    OLED_Refresh_Gram(); // Refresh OLED

    while (NRF24L01_Check()) {
        delay_ms(100);
        Beeper = !Beeper; // Beep at 5Hz if wireless module fails
    }
    Beeper = 0; // Stop beeping
    delay_ms(1000);
    OLED_Clear_GRAM(); // Clear OLED

    if (setData.clockCheck == ON) { // Throttle self-check
        if (PWMvalue[2] > 1200) {
            OLED_ShowString(33, 16, (u8 *)"THROTTLE", 16, 1);
            OLED_ShowString(42, 32, (u8 *)"WARNING!", 12, 1);
            OLED_Refresh_Gram(); // Refresh display memory
        }
        while (PWMvalue[2] > 1200) {}
        OLED_Clear_GRAM(); // Clear OLED
    }
    if (setData.NRF_Mode == ON) {
        NRF24L01_TX_Mode(setData.NRF_Power); // Transmit mode
    } else {
        NRF24L01_LowPower_Mode(); // Low power mode
    }
    homeWindow(); // Display home screen
    OLED_Refresh_Gram(); // Refresh OLED
}
/* Loop Function */
void loop(void) {
    if (clockTime > setData.clockTime * 60 * 50 && setData.clockMode == ON) {
        if (clockCount % 5 == 0) {
            beeperOnce(20);
            if (nowMenuIndex == home) {
                OLED_DrawPointBMP(65, 1, iconClock, 15, 12, 1); // Clock icon
                OLED_Refresh_Gram(); // Refresh OLED
            }
        } else {
            delay_ms(20);
        }
        if (clockCount % 10 == 0 && nowMenuIndex == home) {
            OLED_DrawPointBMP(65, 1, iconAlarm, 16, 12, 1); // Alarm icon
            drawClockTime(); // Display time
            OLED_Refresh_Gram(); // Refresh OLED
        }
        clockCount++;
        if (clockCount > 100) { // Alarm for 2s
            clockTime = 0; // Reset clock time
            clockCount = 0;
        }
    }
    if (loopCount % 100 == 0 && nowMenuIndex == home) {
        drawClockTime();
        showSwState();
        thrNum = (int)(PWMvalue[2] - 1000) / 22;
        if (setData.throttlePreference) {
            OLED_Fill(2, 62 - thrNum, 2, 62, 0);
            OLED_Fill(2, 16, 2, 62 - thrNum, 1);
        } else {
            OLED_Fill(125, 62 - thrNum, 125, 62, 0);
            OLED_Fill(125, 16, 125, 62 - thrNum, 1);
        }
        if (loopCount % REFRESH_INTERVAL == 0) {
            if (batVoltSignal == 1) beeperOnce(10);
            char percentageStr[5];
            if (percentage < 10) {
                sprintf((char *)percentageStr, " %d%%", (int)percentage);
            } else {
                sprintf((char *)percentageStr, "%d%%", (int)percentage);
            }
            OLED_ShowString(82, 3, (u8 *)percentageStr, 12, 1);

            int fillPixels;
            if (batVolt <= MIN_VOLTAGE) {
                fillPixels = 0;
            } else if (batVolt >= MAX_VOLTAGE) {
                fillPixels = MAX_FILL_PIXELS;
            } else {
                fillPixels = (int)((batVolt - MIN_VOLTAGE) * (MAX_FILL_PIXELS / (MAX_VOLTAGE - MIN_VOLTAGE)));
            }
            OLED_Fill(106, 3, 122, 12, 0);
            OLED_Fill(106, 3, (u16)(106 + fillPixels), 12, 1);
        }

        // Update signal strength and display icon
        updateSignalStrength();

        OLED_Refresh_Gram();
    }
    if (keyEvent > 0) { // Key event handling
        keyDownSound();
        keyEventHandle();
    }
    if (nowMenuIndex == xcjz14) { // Travel calibration
        menu_xcjz14();
        OLED_Refresh_Gram(); // Refresh OLED
        for (int i = 0; i < 4; i++) {
            if (chResult[i] > setData.chUpper[i]) setData.chUpper[i] = chResult[i];
            if (chResult[i] < setData.chLower[i]) setData.chLower[i] = chResult[i];
        }
    }
    if (nowMenuIndex == dljs18) { // Rudder quantity monitoring
        menu_dljs18();
        OLED_Refresh_Gram(); // Refresh OLED
    }
    if (menuEvent[0]) { // Menu event
        keyDownSound();
        menuEventHandle();
    }
    lastMenuIndex = nowMenuIndex;
    loopCount++;
}

/* Main Function */
int main() {
    setup();
    while (1) {
        loop();
    }
}

// Fine-tuning event handling function: update the main interface
void keyEventHandle(void)
{
	if (nowMenuIndex == home)
	{
		if (keyEvent == 1 || keyEvent == 2) 
		{
			if (setData.throttlePreference) // Left-hand throttle
			{ 
				// Channel 1 fine-tuning - horizontal line (to the right)
				OLED_Fill(66, 61, 119, 61, 1); // Write 1, clear previous marker
				loca = (int)93 + setData.PWMadjustValue[0] / 12.5;
				OLED_Fill(loca - 2, 61, loca + 2, 61, 0); // Write 0
			}
			else // Right-hand throttle
			{ 
				// Channel 4 fine-tuning - horizontal line (to the right)
				OLED_Fill(66, 61, 119, 61, 1); // Write 1, clear previous marker
				loca = (int)93 + setData.PWMadjustValue[3] / 12.5;
				OLED_Fill(loca - 2, 61, loca + 2, 61, 0); // Write 0
			}
		}
		if (keyEvent == 3 || keyEvent == 4) 
		{
			if (setData.throttlePreference) // Left-hand throttle
			{ 
				// Channel 2 fine-tuning - vertical line (to the right)
				OLED_Fill(125, 16, 125, 62, 1); // Write 1
				loca = (int)39 - setData.PWMadjustValue[1] / 14.29;
				OLED_Fill(125, loca - 2, 125, loca + 2, 0); // Write 1
			}
			else // Right-hand throttle
			{ 
				// Channel 2 fine-tuning - vertical line (to the left)
				OLED_Fill(2, 16, 2, 56, 1); // Write 1
				loca = (int)39 - setData.PWMadjustValue[1] / 12;
				OLED_Fill(2, loca - 2, 2, loca + 2, 0); // Write 1
			}
		}
		if (keyEvent == 5 || keyEvent == 6) 
		{	
			if (setData.throttlePreference) // Left-hand throttle
			{ 
				// Channel 4 fine-tuning - horizontal line (to the left)
				OLED_Fill(7, 61, 61, 61, 1); // Write 1, clear previous marker
				loca = (int)35 + setData.PWMadjustValue[3] / 12.5;
				OLED_Fill(loca - 2, 61, loca + 2, 61, 0); // Write 0
			}
			else // Right-hand throttle
			{ 
				// Channel 1 fine-tuning - horizontal line (to the left)
				OLED_Fill(7, 61, 61, 61, 1); // Write 1, clear previous marker
				loca = (int)34 + setData.PWMadjustValue[0] / 12.5;
				OLED_Fill(loca - 2, 61, loca + 2, 61, 0); // Write 0
			}
		}
		OLED_Refresh_Gram(); // Refresh the display memory
		STMFLASH_Write(FLASH_SAVE_ADDR, (u16 *)&setData, setDataSize); // Write user data to FLASH
	}
	keyEvent = 0; // Reset key event
}


void addSignalStrengthSample(int newSample) {
    signalStrengthSamples[currentSampleIndex] = newSample;
    currentSampleIndex = (currentSampleIndex + 1) % SIGNAL_SAMPLES;
}

int getAverageSignalStrength(void) {
    int sum = 0;
    for (int i = 0; i < SIGNAL_SAMPLES; i++) {
        sum += signalStrengthSamples[i];
    }
    return sum / SIGNAL_SAMPLES;
}

void displaySignalIcon(int strength) {
    if (strength == 0) {
        OLED_DrawPointBMP(48, 1, iconSignalOff, 15, 12, 1);
    } else if (strength > 0 && strength <= 25) {
        OLED_DrawPointBMP(48, 1, iconSignal25, 15, 12, 1);
    } else if (strength > 25 && strength <= 50) {
        OLED_DrawPointBMP(48, 1, iconSignal50, 15, 12, 1);
    } else if (strength > 50 && strength <= 75) {
        OLED_DrawPointBMP(48, 1, iconSignal75, 15, 12, 1);
    } else {
        OLED_DrawPointBMP(48, 1, iconSignal100, 15, 12, 1);
    }
}

void updateSignalStrength(void) {
    int currentStrength = getSignalStrength();
    addSignalStrengthSample(currentStrength);
    int averageStrength = getAverageSignalStrength();
	// Calibrate signal strength values here if needed
    if (averageStrength > 15) {
        averageStrength = 100;
    }
    displaySignalIcon(averageStrength);

    // Check if receiver is connected based on signal strength
    if (averageStrength > 0) {
        if (!previouslyConnected) {
            // Beep twice for 500ms each when the receiver connects
            beeperTwiceOnce(100);
            previouslyConnected = true;
        }
    } else {
        previouslyConnected = false;
    }
}

void menuEventHandle(void)
{
    OLED_display(); // Display the OLED interface
    if(nowMenuIndex == xcjz14 && lastMenuIndex != xcjz14) // Channel neutral point calibration
    {
        for(int i = 0; i < 4; i++)
        {
            setData.chLower[i] = chResult[i]; // Update the minimum values of the joystick
            setData.chMiddle[i] = chResult[i]; // Update the middle values of the joystick
            setData.chUpper[i] = chResult[i]; // Update the maximum values of the joystick
        }
    }
    
    for(int i = 0; i < 4; i++) // Limit fine-tuning range

	{
		if(setData.PWMadjustValue[i]>300-setData.PWMadjustUnit) setData.PWMadjustValue[i]=300-setData.PWMadjustUnit;
		if(setData.PWMadjustValue[i]<setData.PWMadjustUnit-300) setData.PWMadjustValue[i]=setData.PWMadjustUnit-300;
	}
	if(menuEvent[1]==NUM_up)
	{
		if(nowMenuIndex==tdwt1){setData.PWMadjustValue[0] += setData.PWMadjustUnit;menu_tdwt1();}
		else if(nowMenuIndex==tdwt2){setData.PWMadjustValue[1] += setData.PWMadjustUnit;menu_tdwt2();}
		else if(nowMenuIndex==tdwt3){setData.PWMadjustValue[2] += setData.PWMadjustUnit;menu_tdwt3();}
		else if(nowMenuIndex==tdwt4){setData.PWMadjustValue[3] += setData.PWMadjustUnit;menu_tdwt4();}
		else if(nowMenuIndex==tdwt5){setData.PWMadjustValue[4] += setData.PWMadjustUnit;menu_tdwt5();}
		else if(nowMenuIndex==tdwt6){setData.PWMadjustValue[5] += setData.PWMadjustUnit;menu_tdwt6();}
		else if(nowMenuIndex==tdwt7){setData.PWMadjustValue[6] += setData.PWMadjustUnit;menu_tdwt7();}
		else if(nowMenuIndex==tdwt8){setData.PWMadjustValue[7] += setData.PWMadjustUnit;menu_tdwt8();}
		else if(nowMenuIndex==tdzf1){setData.chReverse[0] = !setData.chReverse[0];menu_tdzf1();}
		else if(nowMenuIndex==tdzf2){setData.chReverse[1] = !setData.chReverse[1];menu_tdzf2();}
		else if(nowMenuIndex==tdzf3){setData.chReverse[2] = !setData.chReverse[2];menu_tdzf3();}
		else if(nowMenuIndex==tdzf4){setData.chReverse[3] = !setData.chReverse[3];menu_tdzf4();}
		else if(nowMenuIndex==tdzf5){setData.chReverse[4] = !setData.chReverse[4];menu_tdzf5();}
		else if(nowMenuIndex==tdzf6){setData.chReverse[5] = !setData.chReverse[5];menu_tdzf6();}
		else if(nowMenuIndex==tdzf7){setData.chReverse[6] = !setData.chReverse[6];menu_tdzf7();}
		else if(nowMenuIndex==tdzf8){setData.chReverse[7] = !setData.chReverse[7];menu_tdzf8();}
		else if(nowMenuIndex==ymph) {setData.throttlePreference = !setData.throttlePreference;menu_ymph();}
		else if(nowMenuIndex==dyjz) {setData.batVoltAdjust += 1;menu_dyjz();}
		else if(nowMenuIndex==bjdy) {setData.warnBatVolt += 0.1;menu_bjdy();}
		else if(nowMenuIndex==jsbj) {setData.RecWarnBatVolt += 0.1;menu_jsbj();}
		else if(nowMenuIndex==wtdw) 
		{
			setData.PWMadjustUnit += 1;
			if(setData.PWMadjustUnit>9) {setData.PWMadjustUnit = 9;}//����΢����λ��Χ
			menu_wtdw();
		}
		else if(nowMenuIndex==xzmx) {setData.modelType += 1;if(setData.modelType>2) {setData.modelType=0;}menu_xzmx();}
		else if(nowMenuIndex==wxfs) {setData.NRF_Mode =!setData.NRF_Mode;menu_wxfs();}
		else if(nowMenuIndex==ppmsc) {setData.PPM_Out =!setData.PPM_Out;menu_ppmsc();}
		else if(nowMenuIndex==ajyx) {setData.keySound =!setData.keySound;menu_ajyx();}
		else if(nowMenuIndex==kjhm) {setData.onImage =!setData.onImage;menu_kjhm();}
		else if(nowMenuIndex==nzbj) {setData.clockMode =!setData.clockMode;menu_nzbj();}
		else if(nowMenuIndex==nzsc) 
		{
			setData.clockTime += 1;
			if(setData.clockTime>60) {setData.clockTime=60;}// Limit alarm duration
			menu_nzsc();
		}
		else if(nowMenuIndex==kjzj) {setData.clockCheck =!setData.clockCheck;menu_kjzj();}
		else if(nowMenuIndex==skbh) 
		{
			setData.throttleProtect += 5;
			if(setData.throttleProtect>100) {setData.throttleProtect = 100;}// Limit throttle protection value
			menu_skbh();
		}
		else if(nowMenuIndex==fsgl)
		{
			setData.NRF_Power += 2;
			if(setData.NRF_Power>0x0f) {setData.NRF_Power=0x0f;}// Limit power to 11, 13, 15
			menu_fsgl();
		}
		else {}
	}
	if(menuEvent[1]==NUM_down)
	{
		if(nowMenuIndex==tdwt1){setData.PWMadjustValue[0] -= setData.PWMadjustUnit;menu_tdwt1();}
		else if(nowMenuIndex==tdwt2){setData.PWMadjustValue[1] -= setData.PWMadjustUnit;menu_tdwt2();}
		else if(nowMenuIndex==tdwt3){setData.PWMadjustValue[2] -= setData.PWMadjustUnit;menu_tdwt3();}
		else if(nowMenuIndex==tdwt4){setData.PWMadjustValue[3] -= setData.PWMadjustUnit;menu_tdwt4();}
		else if(nowMenuIndex==tdwt5){setData.PWMadjustValue[4] -= setData.PWMadjustUnit;menu_tdwt5();}
		else if(nowMenuIndex==tdwt6){setData.PWMadjustValue[5] -= setData.PWMadjustUnit;menu_tdwt6();}
		else if(nowMenuIndex==tdwt7){setData.PWMadjustValue[6] -= setData.PWMadjustUnit;menu_tdwt7();}
		else if(nowMenuIndex==tdwt8){setData.PWMadjustValue[7] -= setData.PWMadjustUnit;menu_tdwt8();}
		else if(nowMenuIndex==tdzf1){setData.chReverse[0] = !setData.chReverse[0];menu_tdzf1();}
		else if(nowMenuIndex==tdzf2){setData.chReverse[1] = !setData.chReverse[1];menu_tdzf2();}
		else if(nowMenuIndex==tdzf3){setData.chReverse[2] = !setData.chReverse[2];menu_tdzf3();}
		else if(nowMenuIndex==tdzf4){setData.chReverse[3] = !setData.chReverse[3];menu_tdzf4();}
		else if(nowMenuIndex==tdzf5){setData.chReverse[4] = !setData.chReverse[4];menu_tdzf5();}
		else if(nowMenuIndex==tdzf6){setData.chReverse[5] = !setData.chReverse[5];menu_tdzf6();}
		else if(nowMenuIndex==tdzf7){setData.chReverse[6] = !setData.chReverse[6];menu_tdzf7();}
		else if(nowMenuIndex==tdzf8){setData.chReverse[7] = !setData.chReverse[7];menu_tdzf8();}
		else if(nowMenuIndex==ymph) {setData.throttlePreference = !setData.throttlePreference;menu_ymph();}
		else if(nowMenuIndex==dyjz) {setData.batVoltAdjust -= 1;menu_dyjz();}
		else if(nowMenuIndex==bjdy) {setData.warnBatVolt -= 0.1;menu_bjdy();}
		else if(nowMenuIndex==jsbj) {setData.RecWarnBatVolt -= 0.1;menu_jsbj();}
		else if(nowMenuIndex==wtdw) 
		{
			setData.PWMadjustUnit -= 1;
			if(setData.PWMadjustUnit<1) {setData.PWMadjustUnit = 1;}// Limit the range of adjustment units
			menu_wtdw();
		}
		else if(nowMenuIndex==xzmx) {if(setData.modelType==0){setData.modelType=2;}else {setData.modelType -= 1;}menu_xzmx();}
		else if(nowMenuIndex==wxfs) {setData.NRF_Mode =!setData.NRF_Mode;menu_wxfs();}
		else if(nowMenuIndex==ppmsc) {setData.PPM_Out =!setData.PPM_Out;menu_ppmsc();}
		else if(nowMenuIndex==ajyx) {setData.keySound =!setData.keySound;menu_ajyx();}
		else if(nowMenuIndex==kjhm) {setData.onImage =!setData.onImage;menu_kjhm();}
		else if(nowMenuIndex==nzbj) {setData.clockMode =!setData.clockMode;menu_nzbj();}
		else if(nowMenuIndex==nzsc) 
		{
			setData.clockTime -= 1;
			if(setData.clockTime<1) {setData.clockTime=1;}// Limit the duration of the alarm
			menu_nzsc();
		}
		else if(nowMenuIndex==kjzj) {setData.clockCheck =!setData.clockCheck;menu_kjzj();}
		else if(nowMenuIndex==skbh) 
		{
			if(setData.throttleProtect<5) {setData.throttleProtect = 5;}// Limit throttle protection value
			setData.throttleProtect -= 5;
			menu_skbh();
		}
		else if(nowMenuIndex==fsgl)
		{
			setData.NRF_Power -= 2;
			if(setData.NRF_Power<0x0b) {setData.NRF_Power=0x0b;}// Limit power 11, 13, 15
			menu_fsgl();
		}
		else {}
	}
	if(menuEvent[1]==MENU_enter)// Change menu display after a short press of the rotary encoder
	{
		if(nowMenuIndex==tdwt1){menu_tdwt1();}
		else if(nowMenuIndex==tdwt2){menu_tdwt2();}
		else if(nowMenuIndex==tdwt3){menu_tdwt3();}
		else if(nowMenuIndex==tdwt4){menu_tdwt4();}
		else if(nowMenuIndex==tdwt5){menu_tdwt5();}
		else if(nowMenuIndex==tdwt6){menu_tdwt6();}
		else if(nowMenuIndex==tdwt7){menu_tdwt7();}
		else if(nowMenuIndex==tdwt8){menu_tdwt8();}
		else if(nowMenuIndex==tdzf1){menu_tdzf1();}
		else if(nowMenuIndex==tdzf2){menu_tdzf2();}
		else if(nowMenuIndex==tdzf3){menu_tdzf3();}
		else if(nowMenuIndex==tdzf4){menu_tdzf4();}
		else if(nowMenuIndex==tdzf5){menu_tdzf5();}
		else if(nowMenuIndex==tdzf6){menu_tdzf6();}
		else if(nowMenuIndex==tdzf7){menu_tdzf7();}
		else if(nowMenuIndex==tdzf8){menu_tdzf8();}
		else if(nowMenuIndex==ymph) {menu_ymph();}
		else if(nowMenuIndex==dyjz) {menu_dyjz();}
		else if(nowMenuIndex==bjdy) {menu_bjdy();}
		else if(nowMenuIndex==wtdw) {menu_wtdw();}
		else if(nowMenuIndex==xzmx) {menu_xzmx();}
		else if(nowMenuIndex==wxfs) {menu_wxfs();}
		else if(nowMenuIndex==ppmsc) {menu_ppmsc();}
		else if(nowMenuIndex==ajyx) {menu_ajyx();}
		else if(nowMenuIndex==kjhm) {menu_kjhm();}
		else if(nowMenuIndex==nzbj) {menu_nzbj();}
		else if(nowMenuIndex==nzsc) {menu_nzsc();}
		else if(nowMenuIndex==kjzj) {menu_kjzj();}
		else if(nowMenuIndex==jsbj) {menu_jsbj();}
		else if(nowMenuIndex==skbh) {menu_skbh();}
		else if(nowMenuIndex==fsgl) {menu_fsgl();}
		else {}
	}
	if(nowMenuIndex!=lastMenuIndex)
	{
		STMFLASH_Write(FLASH_SAVE_ADDR,(u16 *)&setData,setDataSize);// Write user data to FLASH
	}
	OLED_Refresh_Gram();//OLED CLEAR GRAM
	menuEvent[0] = 0;
}

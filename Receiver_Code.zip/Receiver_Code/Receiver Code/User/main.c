/*
    Chip: STM32F103C8T6, implements NRF24L01 wireless reception and 8-channel PWM output

    NRF24L01 Module:
                GND      Power ground
                VCC      Connect to 3.3V power
                CSN      PB12
                SCK      PB13
                MISO     PB14
                MOSI     PB15
                CE       PA8
                IRQ      PA9

    PWM Output: PA0-3, PA6-7, PB0-1

    OLED Display:
                GND      Power ground
                VCC      Connect to 3.3V power
                SCL      Connect to PB8 (SCL)
                SDA      Connect to PB9 (SDA)

    Serial USB-TTL Connection:
                GND      Power ground
                3V3      Connect to 3.3V
                TXD      Connect to PB7
                RXD      Connect to PB6

    ST-LINK V2 Connection:
                GND      Power ground
                3V3      Connect to 3.3V
                SWCLK    Connect to DCLK
                SWDIO    Connect to DIO
*/

#include "main.h"
#include "delay.h"
#include "usart.h"
#include "stm32f10x.h"
#include "rtc.h" 
#include "stdio.h"
#include "string.h"
#include "nrf24l01.h"
#include "led.h"
#include "tim.h"
#include "sbus.h"
#include "pwm.h"
#include "ppm.h"

u16 PWMvalue[SBUS_CHANNEL_NUMBER]; // Controls PWM duty cycle
u16 recPWMvalue[SBUS_CHANNEL_NUMBER]; // Controls PWM duty cycle
u8 sbusPacket[SBUS_PACKET_LENGTH]; // 25-byte SBUS data packet
u8 signalLoss = 0;  // 1 indicates signal loss
u16 i=0,startIndex=0;
u32 lastTime = 0;
u32 sbusTime = 0;
u8 chPacket[32];

void PWM_reset(void);

int main()
{
//	delay_init(); // Initialize delay function
	PWM_reset();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); // Set NVIC interrupt group 2, with 2 bits for pre-emption priority and 2 bits for sub-priority
	usart_init(100000); // Initialize UART1 as SBUS output (Baud rate: 100000, 8 data bits, even parity, 2 stop bits)
	// usart_init(115200);
	TIM3_PWM_Init(19999, 71); // Prescaler 72, frequency 1 MHz, period 1 ��s; auto-reload value 20,000, resulting in PWM period of 1 ��s * 20,000
	TIM2_PWM_Init(19999, 71); // PWM output
	TIM4_Counter_Init(9, 71); // Prescaler 1 MHz, period 1 ��s, auto-reload value 10, resulting in minimum count unit of 10 ��s
	PPM_Pin_Init(); // Initialize PPM pin
	systick_init(10000); // Initialize PPM timer with an arbitrary initial value
	LED_Init();		// Initialize LED
	NRF24L01_Init(); // Initialize NRF24L01
	while(NRF24L01_Check()) {
 		delay_ms(200);
	}
	
	NRF24L01_RX_Mode();
	while (1) { 	
		if(NRF24L01_RxPacket(chPacket) == 0) {
			for(i = 0; i < 32 - chNum * 2; i++) { // Find start position, usually at 2nd-3rd element
				if(chPacket[i] == 0x00 && chPacket[i+1] == 0x00) {
					startIndex = i + 2;
					break;
				}
			}
			for(i = 0; i < chNum; i++) { // Process starting from startIndex
				recPWMvalue[i] = ((u16)chPacket[startIndex] << 8) | ((u16)(chPacket[startIndex + 1])); // Combine u8 to u16
				if(recPWMvalue[i] != 0) PWMvalue[i] = recPWMvalue[i];
				startIndex += 2;
			}
			for (i = chNum; i < 16; i++) {
				PWMvalue[i] = 1500; // Set unused channels to midpoint
			}
			//printf("%d,%d,%d,%d\n",PWMvalue[4],PWMvalue[5],PWMvalue[6],PWMvalue[7]);
			signalLoss = 0; // Signal connected flag
			LED = 0;
			lastTime = nowTime;
		}
		
		if (nowTime > sbusTime) // Output SBUS
{
	sbusPreparePacket(sbusPacket, PWMvalue, signalLoss, 0); // Convert channel values into SBUS data packet
	for(i = 0; i < SBUS_PACKET_LENGTH; i++)
	{
		USART_SendData(USART1, sbusPacket[i]); // Send SBUS data packet via USART TX0
		while(USART_GetFlagStatus(USART1, USART_FLAG_TC) != SET); // Wait until transmission is complete
	}
	sbusTime = nowTime + SBUS_UPDATE_RATE * 100; // Update every 10ms
}

//	printf("%d\t%d\n", nowTime, lastTime);
if (nowTime - lastTime > 100 * 2000) // If more than 2 seconds since last reception, signal loss is assumed
{
	LED = !LED;
	signalLoss = 1; // Set signal loss flag
	PWM_reset(); // Trigger failsafe
	delay_ms(200);
}

// PPM data conversion
for (i = 0; i < chNum; i++) {
	chTime[i] = PWMvalue[i] * 9;
}
TIM_SetCompare1(TIM2, PWMvalue[0]); // Output to PWM-PA0
TIM_SetCompare2(TIM2, PWMvalue[1]); // Output to PWM-PA1
TIM_SetCompare3(TIM2, PWMvalue[2]); // Output to PWM-PA2
TIM_SetCompare4(TIM2, PWMvalue[3]); // Output to PWM-PA3
TIM_SetCompare1(TIM3, PWMvalue[4]); // Output to PWM-PA6
TIM_SetCompare2(TIM3, PWMvalue[5]); // Output to PWM-PA7
TIM_SetCompare3(TIM3, PWMvalue[6]); // Output to PWM-PB0
TIM_SetCompare4(TIM3, PWMvalue[7]); // Output to PWM-PB1
	}
}
// Initialize PWM output and failsafe protection
void PWM_reset(void)
{
	PWMvalue[0] = 1500; // Center Channel 1
	PWMvalue[1] = 1500; // Center Channel 2
	PWMvalue[2] = 1000; // Set throttle to minimum
	PWMvalue[3] = 1500; // Center Channel 4
	for (i = 4; i < chNum; i++) 
	{
		PWMvalue[i] = 1500; // Center all unused channels
	}
}



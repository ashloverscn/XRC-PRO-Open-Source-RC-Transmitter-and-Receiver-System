#include "main.h"
#include "pwm.h"
#include "delay.h"
#include "usart.h"
#include "sys.h"
#include "rtc.h" 


// TIM3 PB5 PWM output initialization
// arr: auto-reload value
// psc: clock prescaler
void TIM3_PB5_PWM_Init(u16 arr, u16 psc)
{  
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	
	// Enable TIM3 clock
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	// Enable GPIO peripheral and AFIO alternate function module clocks
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);  

	// Configure partial remapping for TIM3, enabling TIM3_CH2 to map to PB5
	GPIO_PinRemapConfig(GPIO_PartialRemap_TIM3, ENABLE);  
 
	// Set PB5 to alternate function output to output PWM waveform from TIM3 CH2
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;   // TIM_CH2
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  // Push-pull output
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);  // Initialize GPIOB
 
	// Initialize TIM3 with basic parameters
	TIM_TimeBaseStructure.TIM_Period = arr; // Sets auto-reload value for the next update event
	TIM_TimeBaseStructure.TIM_Prescaler = psc; // Sets the prescaler for TIM3 clock frequency division
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; // No clock division, TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; // TIM upcounting mode
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); // Initialize TIM3 time base with the specified parameters
	
	// Initialize TIM3 Channel2 in PWM mode	 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; // Selects PWM mode 1 (output high while counter < auto-reload value)
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; // Enables output compare
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; // Sets output polarity to high
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);  // Initialize TIM3 OC2 with the specified parameters

	// Enable preload register for TIM3 on CCR2
	TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);

	// Enable TIM3
	TIM_Cmd(TIM3, ENABLE);
}

/*=======================================================
* Function: void TIM2_PWM_Init(u16 arr, u16 psc)
* Purpose: Generate 4-channel PWM output using TIM2
* Parameters: None
* Returns: None
=======================================================*/
void TIM2_PWM_Init(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);	//ʹ�ܶ�ʱ��3ʱ��
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  //ʹ��GPIO����ʱ��
	    
 
   //����PA0-3����Ϊ�����������,���PWM���岨��
	GPIO_InitStructure.GPIO_Pin = CH1_Pin|CH2_Pin|CH3_Pin|CH4_Pin; //TIM2_CH1-4
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA
	
	
   //��ʼ��TIM2
	TIM_TimeBaseStructure.TIM_Period = arr; //��������һ�������¼�װ�����Զ���װ�ؼĴ������ڵ�ֵ
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //����������ΪTIMxʱ��Ƶ�ʳ�����Ԥ��Ƶֵ 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //����ʱ�ӷָ�:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM���ϼ���ģʽ
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure); //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
	
	//��ʼ��TIM2 Channel1-4 PWMģʽ	 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ1������ֵ<�Զ���װ��ֵʱ������ߵ�ƽ
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //�Ƚ����ʹ��
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //�������:TIM����Ƚϼ��Ը�
	TIM_OC1Init(TIM2, &TIM_OCInitStructure);  //����Tָ���Ĳ�����ʼ������TIM2 OC1
	TIM_OC2Init(TIM2, &TIM_OCInitStructure);  //����Tָ���Ĳ�����ʼ������TIM2 OC2
	TIM_OC3Init(TIM2, &TIM_OCInitStructure);  //����Tָ���Ĳ�����ʼ������TIM2 OC3
	TIM_OC4Init(TIM2, &TIM_OCInitStructure);  //����Tָ���Ĳ�����ʼ������TIM2 OC4

	TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);  //ʹ��TIM2��CCR1�ϵ�Ԥװ�ؼĴ���
	TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);  //ʹ��TIM2��CCR2�ϵ�Ԥװ�ؼĴ���
	TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);  //ʹ��TIM2��CCR3�ϵ�Ԥװ�ؼĴ���
	TIM_OC4PreloadConfig(TIM2, TIM_OCPreload_Enable);  //ʹ��TIM2��CCR4�ϵ�Ԥװ�ؼĴ���

	TIM_Cmd(TIM2, ENABLE);  //ʹ��TIM2
}

/*=======================================================
* Function: void TIM3_PWM_Init(u16 arr, u16 psc)
* Purpose: Generates 4-channel PWM output using TIM3
* Parameters: None
* Return value: None
=======================================================*/ 
void TIM3_PWM_Init(u16 arr, u16 psc)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);  // Enable TIM3 clock
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);  // Enable GPIO peripheral clock

    // Set PA6-7 and PB0-1 pins to alternate function output, output PWM pulse waveform
    GPIO_InitStructure.GPIO_Pin = CH5_Pin | CH6_Pin; // TIM3_CH1-2
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  // Push-pull output
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);  // Initialize GPIOA

    GPIO_InitStructure.GPIO_Pin = CH7_Pin | CH8_Pin; // TIM3_CH3-4
    GPIO_Init(GPIOB, &GPIO_InitStructure);  // Initialize GPIOB

    // Initialize TIM3
    TIM_TimeBaseStructure.TIM_Period = arr; // Set the period value in the auto-reload register
    TIM_TimeBaseStructure.TIM_Prescaler = psc; // Set the prescaler value for TIMx clock frequency division
    TIM_TimeBaseStructure.TIM_ClockDivision = 0; // Set clock division: TDTS = Tck_tim
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  // TIM counting mode: Up
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); // Initialize TIM3 based on specified parameters in TIM_TimeBaseInitStruct

    // Initialize TIM3 Channels 1-4 in PWM mode
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; // Select timer mode: TIM PWM mode 1, output high when counter < auto-reload value
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; // Enable compare output
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; // Output polarity: High
    TIM_OC1Init(TIM3, &TIM_OCInitStructure);  // Initialize TIM3 OC1 based on specified parameters
    TIM_OC2Init(TIM3, &TIM_OCInitStructure);  // Initialize TIM3 OC2
    TIM_OC3Init(TIM3, &TIM_OCInitStructure);  // Initialize TIM3 OC3
    TIM_OC4Init(TIM3, &TIM_OCInitStructure);  // Initialize TIM3 OC4

    TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);  // Enable TIM3 preload register on CCR1
    TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);  // Enable TIM3 preload register on CCR2
    TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);  // Enable TIM3 preload register on CCR3
    TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);  // Enable TIM3 preload register on CCR4

    TIM_Cmd(TIM3, ENABLE);  // Enable TIM3
}



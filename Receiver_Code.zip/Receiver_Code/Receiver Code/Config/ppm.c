#include "main.h"
#include "ppm.h"

void systick_init(u32 count)
{
	SysTick_Config(count); // This line should be set before configuring the clock source, count is assigned to the LOAD register
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); // Select external clock HCLK, count of 9000 000 equals 1s
	SysTick->VAL = 0; // When VAL=0, the reload value in the LOAD register is assigned to VAL as the initial value, decreasing by 1 every SysTick clock cycle
}

void SysTick_Handler(void) // Interrupt entry point
{
    ppm_output();
}

// PPM push-pull output on PA4
void PPM_Pin_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  // Enable GPIO peripheral clock
	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = PPM_Pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(PPM_GPIO_Port, &GPIO_InitStructure);
	GPIO_SetBits(PPM_GPIO_Port, PPM_Pin); // Set PA4 output high
}

u32 chTime[chNum]; // Control PPM duty cycle

enum PPM_OUTPUT_CH_STATE {
    CH_DOWN_STATE,
    CH_UP_STATE,
};

static enum PPM_OUTPUT_CH_STATE state = CH_DOWN_STATE;

#define MS20	(9000 * 20) /* 20ms */
#define MS05	(4500)		/* 0.5ms */

static uint64_t total_value = 0;
static u8 ch_idx = 0;

void ppm_output(void)
{
    u32 ch_val = 0;
    
    // CH1 ~ CH8 and the last low-level period
    if (state == CH_DOWN_STATE) {
		// Enter next timed interrupt after 0.5ms
        systick_init(MS05);
        total_value += MS05;
        state = CH_UP_STATE;
        PPM = 0;
    } 
	else {
        // CH1 ~ CH8 high level
        if (ch_idx < chNum) {
            if (chTime[ch_idx] < MS05)
                ch_val = MS05; // Ensure interval between rising edges is at least 1ms
            else {
                ch_val = chTime[ch_idx] - MS05;
            }
            systick_init(ch_val);
            total_value += ch_val;
            ch_idx++;
        } 
		else {
            // Final high level
            systick_init(MS20 - total_value);
            total_value = 0;
            ch_idx = 0;
        }
        state = CH_DOWN_STATE;
        PPM = 1;
    }     
}

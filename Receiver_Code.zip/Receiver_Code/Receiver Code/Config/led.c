#include "led.h"
#include "main.h"

// Initialize PB5 and PE5 as output ports and enable the clock for these ports.
// LED IO Initialization
void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); // Enable the clock for PC port

    GPIO_InitStructure.GPIO_Pin = LED_Pin; // Configure LED0 to PC13 port
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; // Push-pull output
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; // IO port speed set to 50MHz
    GPIO_Init(LED_GPIO_Port, &GPIO_InitStructure); // Initialize GPIOC13 based on the specified parameters

    GPIO_SetBits(GPIOC, GPIO_Pin_13); // Set PC13 output high
}


#ifndef __SBUS_H
#define __SBUS_H
#include "stm32f10x.h" // Remember to add this header file, as config.c uses GPIO-related functions, etc.
#include "sys.h"

// Define constants for RC channel settings
#define RC_CHANNEL_MIN 1000     // Minimum PWM value for each RC channel
#define RC_CHANNEL_MAX 2000     // Maximum PWM value for each RC channel
#define SBUS_MIN_OFFSET 173      // Minimum value for SBUS protocol
#define SBUS_MID_OFFSET 992      // Midpoint value for SBUS protocol
#define SBUS_MAX_OFFSET 1811     // Maximum value for SBUS protocol
#define SBUS_CHANNEL_NUMBER 16    // Number of SBUS channels: 16 analog, 2 digital
#define SBUS_PACKET_LENGTH 25     // Length of SBUS data packet in bytes
#define SBUS_FRAME_HEADER 0x0f    // SBUS data header, start byte
#define SBUS_FRAME_FOOTER 0x00    // SBUS data footer, end byte
#define SBUS_FRAME_FOOTER_V2 0x04  // Alternative SBUS data footer, end byte 2
#define SBUS_STATE_FAILSAFE 0x08   // Failsafe flag activation
#define SBUS_STATE_SIGNALLOSS 0x04  // Signal loss flag
#define SBUS_UPDATE_RATE 10        // SBUS output update rate in milliseconds

// Function Prototypes

/**
 * Prepares an SBUS data packet with given channels and state flags.
 * @param packet - The byte array to store the prepared SBUS packet
 * @param channels - Array of channel values
 * @param isSignalLoss - Flag indicating signal loss
 * @param isFailsafe - Flag indicating failsafe activation
 */
void sbusPreparePacket(u8 packet[], u16 channels[], u8 isSignalLoss, u8 isFailsafe);

/**
 * Processes SBUS data into channel values.
 * @param SBUS_DATA - Array holding incoming SBUS data
 * @param CH_Rec - Array to store the received channel values
 */
void sbusData(u8 SBUS_DATA[], u16 CH_Rec[]);

/**
 * Maps a value from one range to another, similar to Arduino's map function.
 * @param value - The value to be mapped
 * @param fromLow - The minimum of the original range
 * @param fromHigh - The maximum of the original range
 * @param toLow - The minimum of the target range
 * @param toHigh - The maximum of the target range
 * @return The mapped value
 */
float map(float value, float fromLow, float fromHigh, float toLow, float toHigh);

#endif

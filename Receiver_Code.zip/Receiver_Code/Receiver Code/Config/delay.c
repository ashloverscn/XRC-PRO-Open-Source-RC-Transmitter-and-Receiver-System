#include "delay.h"

/* Static variables for delay calculation 
static u8 fac_us = 0;  // Multiplier for microsecond delay
static u16 fac_ms = 0; // Multiplier for millisecond delay; in OS contexts, represents ms per tick

// Initialize delay function
// SYSTICK clock is set to HCLK divided by 8
// SYSCLK: System clock
void delay_init()
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); // Select external clock source HCLK/8
    fac_us = SystemCoreClock / 8000000;                  // Calculate microsecond multiplier
    fac_ms = (u16)fac_us * 1000;                         // Calculate millisecond multiplier
}

// Delay function for microseconds
// nus: the number of microseconds to delay
void delay_us(u32 nus)
{
    u32 temp;
    SysTick->LOAD = nus * fac_us;                      // Load delay time
    SysTick->VAL = 0x00;                               // Clear counter
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;          // Start countdown
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));    // Wait until time reaches zero
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;         // Disable counter
    SysTick->VAL = 0x00;                               // Clear counter
}

// Delay function for milliseconds
// nms: the number of milliseconds to delay
// Note: Range of nms depends on the SYSCLK frequency
// Max delay = 0xFFFFFF * 8 * 1000 / SYSCLK
void delay_ms(u16 nms)
{
    u32 temp;
    SysTick->LOAD = (u32)nms * fac_ms;                // Load delay time (SysTick->LOAD is 24 bits)
    SysTick->VAL = 0x00;                              // Clear counter
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;         // Start countdown
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));   // Wait until time reaches zero
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;        // Disable counter
    SysTick->VAL = 0x00;                              // Clear counter
}
*/
// Basic delay_us and delay_ms functions with loop-based delay
void delay_us(u32 nus)
{		
    u16 i = 0;
    while (nus--)
    {
        i = 12;
        while (i--);
    }
}

void delay_ms(u16 nms)
{
    u16 i = 0;
    while (nms--)
    {
        i = 12000;
        while (i--);
    }
}
